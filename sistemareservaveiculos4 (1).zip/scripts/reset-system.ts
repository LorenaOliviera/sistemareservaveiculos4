import { executeQuery } from "../lib/db"

async function resetSystem() {
  try {
    console.log("Iniciando reset do sistema...")
    console.log("⚠️ Este processo irá remover todas as reservas e redefinir o status dos veículos.")
    console.log("⚠️ Os usuários cadastrados serão mantidos.")

    // Contagem de reservas antes da limpeza
    const reservationsCount = await executeQuery("SELECT COUNT(*) as count FROM reservations")
    console.log(`Encontradas ${reservationsCount[0].count} reservas para remover.`)

    // Remover todas as reservas
    await executeQuery("DELETE FROM reservations")
    console.log("✅ Todas as reservas foram removidas com sucesso.")

    // Redefinir o status de todos os veículos para "disponível"
    await executeQuery("UPDATE vehicles SET status = 'disponível'")
    console.log("✅ Status de todos os veículos redefinido para 'disponível'.")

    // Verificar se a limpeza foi bem-sucedida
    const remainingReservations = await executeQuery("SELECT COUNT(*) as count FROM reservations")
    if (remainingReservations[0].count === "0") {
      console.log("✅ Verificação concluída: Nenhuma reserva encontrada no sistema.")
    } else {
      console.log(`⚠️ Verificação: Ainda existem ${remainingReservations[0].count} reservas no sistema.`)
    }

    // Contagem de veículos disponíveis
    const availableVehicles = await executeQuery("SELECT COUNT(*) as count FROM vehicles WHERE status = 'disponível'")
    const totalVehicles = await executeQuery("SELECT COUNT(*) as count FROM vehicles")
    console.log(`✅ Veículos disponíveis: ${availableVehicles[0].count}/${totalVehicles[0].count}`)

    // Contagem de usuários mantidos
    const usersCount = await executeQuery("SELECT COUNT(*) as count FROM users")
    console.log(`✅ Usuários mantidos: ${usersCount[0].count}`)

    console.log("\n✅ Reset do sistema concluído com sucesso!")
    console.log("Você pode agora começar a usar o sistema do zero, com os usuários existentes.")
    console.log("Para acessar o sistema, use as credenciais de administrador:")
    console.log("- Email: admin@lenzing.com")
    console.log("- Senha: admin123")
  } catch (error) {
    console.error("❌ Erro ao resetar o sistema:", error)
  } finally {
    process.exit(0)
  }
}

// Função para confirmar a ação
function confirmReset() {
  const readline = require("readline").createInterface({
    input: process.stdin,
    output: process.stdout,
  })

  readline.question(
    "⚠️ ATENÇÃO: Esta ação irá remover TODAS as reservas do sistema. Deseja continuar? (s/n): ",
    (answer) => {
      readline.close()
      if (answer.toLowerCase() === "s") {
        resetSystem()
      } else {
        console.log("Operação cancelada pelo usuário.")
        process.exit(0)
      }
    },
  )
}

// Iniciar o processo com confirmação
confirmReset()
