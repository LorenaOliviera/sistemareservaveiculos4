import { executeQuery } from "../lib/db"

async function initializeDatabase() {
  try {
    console.log("Iniciando criação das tabelas...")

    // Tabela de usuários
    await executeQuery(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(50) NOT NULL DEFAULT 'solicitante',
        status BOOLEAN NOT NULL DEFAULT TRUE,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
        last_login TIMESTAMP
      )
    `)
    console.log("✅ Tabela 'users' criada com sucesso")

    // Tabela de sessões
    await executeQuery(`
      CREATE TABLE IF NOT EXISTS sessions (
        id VARCHAR(255) PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        expires_at TIMESTAMP NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `)
    console.log("✅ Tabela 'sessions' criada com sucesso")

    // Tabela de veículos
    await executeQuery(`
      CREATE TABLE IF NOT EXISTS vehicles (
        id SERIAL PRIMARY KEY,
        plate VARCHAR(20) UNIQUE NOT NULL,
        model VARCHAR(100) NOT NULL,
        year INTEGER,
        color VARCHAR(50),
        capacity INTEGER DEFAULT 5,
        status VARCHAR(50) NOT NULL DEFAULT 'disponível',
        location VARCHAR(50) NOT NULL,
        maintenance_date TIMESTAMP,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `)
    console.log("✅ Tabela 'vehicles' criada com sucesso")

    // Tabela de reservas
    await executeQuery(`
      CREATE TABLE IF NOT EXISTS reservations (
        id SERIAL PRIMARY KEY,
        reservation_code VARCHAR(20) UNIQUE NOT NULL,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        vehicle_id INTEGER NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
        requester_name VARCHAR(255) NOT NULL,
        cost_center VARCHAR(100) NOT NULL,
        pickup_date DATE NOT NULL,
        return_date DATE NOT NULL,
        pickup_time TIME NOT NULL,
        return_time TIME NOT NULL,
        location VARCHAR(50) NOT NULL,
        reason TEXT NOT NULL,
        status VARCHAR(50) NOT NULL DEFAULT 'pendente',
        rejection_reason TEXT,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `)
    console.log("✅ Tabela 'reservations' criada com sucesso")

    // Criar usuários de teste
    const adminExists = await executeQuery("SELECT * FROM users WHERE email = $1", ["admin@lenzing.com"])
    if (adminExists.length === 0) {
      // Senha: admin123
      await executeQuery(`
        INSERT INTO users (name, email, password, role)
        VALUES ('Administrador', 'admin@lenzing.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'admin')
      `)
      console.log("✅ Usuário administrador criado com sucesso")
    }

    const userExists = await executeQuery("SELECT * FROM users WHERE email = $1", ["solicitante@lenzing.com"])
    if (userExists.length === 0) {
      // Senha: admin123
      await executeQuery(`
        INSERT INTO users (name, email, password, role)
        VALUES ('Solicitante', 'solicitante@lenzing.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'solicitante')
      `)
      console.log("✅ Usuário solicitante criado com sucesso")
    }

    // Criar veículos de teste
    const vehicleExists = await executeQuery("SELECT * FROM vehicles WHERE plate = $1", ["ABC1234"])
    if (vehicleExists.length === 0) {
      await executeQuery(`
        INSERT INTO vehicles (plate, model, year, color, capacity, status, location)
        VALUES 
        ('ABC1234', 'Toyota Corolla', 2022, 'Prata', 5, 'disponível', 'MG1'),
        ('DEF5678', 'Honda Civic', 2021, 'Preto', 5, 'disponível', 'MG1'),
        ('GHI9012', 'Volkswagen Gol', 2020, 'Branco', 5, 'disponível', 'MG2'),
        ('JKL3456', 'Fiat Strada', 2022, 'Vermelho', 2, 'disponível', 'MG2'),
        ('MNO7890', 'Ford Ranger', 2021, 'Azul', 5, 'disponível', 'MG1')
      `)
      console.log("✅ Veículos de teste criados com sucesso")
    }

    console.log("✅ Banco de dados inicializado com sucesso!")
  } catch (error) {
    console.error("❌ Erro ao inicializar o banco de dados:", error)
  } finally {
    process.exit(0)
  }
}

initializeDatabase()
