import { executeQuery } from "../lib/db"

async function updateDatabase() {
  try {
    console.log("Iniciando atualização do banco de dados...")

    // Verificar se a coluna updated_at existe na tabela users
    const checkUserColumn = await executeQuery(`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'users' AND column_name = 'updated_at'
    `)

    if (checkUserColumn.length === 0) {
      console.log("Adicionando coluna updated_at à tabela users...")
      await executeQuery(`
        ALTER TABLE users 
        ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      `)
      console.log("✅ Coluna updated_at adicionada com sucesso")
    } else {
      console.log("✅ Coluna updated_at já existe na tabela users")
    }

    // Verificar se a coluna rejection_reason existe na tabela reservations
    const checkReservationColumn = await executeQuery(`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'reservations' AND column_name = 'rejection_reason'
    `)

    if (checkReservationColumn.length === 0) {
      console.log("Adicionando coluna rejection_reason à tabela reservations...")
      await executeQuery(`
        ALTER TABLE reservations 
        ADD COLUMN rejection_reason TEXT
      `)
      console.log("✅ Coluna rejection_reason adicionada com sucesso")
    } else {
      console.log("✅ Coluna rejection_reason já existe na tabela reservations")
    }

    console.log("✅ Banco de dados atualizado com sucesso!")
  } catch (error) {
    console.error("❌ Erro ao atualizar o banco de dados:", error)
  } finally {
    process.exit(0)
  }
}

updateDatabase()
