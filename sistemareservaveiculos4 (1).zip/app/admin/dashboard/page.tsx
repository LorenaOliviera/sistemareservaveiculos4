import { requireAdmin } from "@/lib/auth"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { executeQuery } from "@/lib/db"
import { AdminDashboardContent } from "./admin-dashboard-content"

export default async function AdminDashboardPage() {
  const user = await requireAdmin()

  // Busca estatísticas de reservas
  const reservationStats = await executeQuery(`
    SELECT 
      COUNT(*) FILTER (WHERE status = 'pendente') as pending_count,
      COUNT(*) FILTER (WHERE status = 'aprovada') as approved_count,
      COUNT(*) FILTER (WHERE status = 'em_andamento') as ongoing_count,
      COUNT(*) FILTER (WHERE status = 'concluida') as completed_count,
      COUNT(*) FILTER (WHERE status = 'cancelada') as canceled_count,
      COUNT(*) as total_count
    FROM reservations
  `)

  // Busca estatísticas de veículos
  const vehicleStats = await executeQuery(`
    SELECT 
      COUNT(*) FILTER (WHERE status = 'disponível') as available_count,
      COUNT(*) FILTER (WHERE status = 'em_uso') as in_use_count,
      COUNT(*) FILTER (WHERE status = 'manutenção') as maintenance_count,
      COUNT(*) as total_count
    FROM vehicles
  `)

  // Busca estatísticas de usuários
  const userStats = await executeQuery(`
    SELECT 
      COUNT(*) FILTER (WHERE role = 'admin') as admin_count,
      COUNT(*) FILTER (WHERE role = 'solicitante') as requester_count,
      COUNT(*) FILTER (WHERE status = TRUE) as active_count,
      COUNT(*) FILTER (WHERE status = FALSE) as inactive_count,
      COUNT(*) as total_count
    FROM users
  `)

  // Busca reservas recentes
  const recentReservations = await executeQuery(`
    SELECT r.*, v.model as vehicle_model, v.plate as vehicle_plate, u.name as user_name
    FROM reservations r
    JOIN vehicles v ON r.vehicle_id = v.id
    JOIN users u ON r.user_id = u.id
    ORDER BY r.created_at DESC
    LIMIT 5
  `)

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard Administrativo</h1>
          <p className="text-muted-foreground">Visão geral do sistema de reserva de veículos</p>
        </div>

        <Tabs defaultValue="mg1">
          <TabsList>
            <TabsTrigger value="mg1">MG1</TabsTrigger>
            <TabsTrigger value="mg2">MG2</TabsTrigger>
            <TabsTrigger value="all">Todos</TabsTrigger>
          </TabsList>

          <TabsContent value="mg1">
            <AdminDashboardContent
              location="MG1"
              reservationStats={reservationStats[0]}
              vehicleStats={vehicleStats[0]}
              userStats={userStats[0]}
              recentReservations={recentReservations.filter((r) => r.location === "MG1")}
            />
          </TabsContent>

          <TabsContent value="mg2">
            <AdminDashboardContent
              location="MG2"
              reservationStats={reservationStats[0]}
              vehicleStats={vehicleStats[0]}
              userStats={userStats[0]}
              recentReservations={recentReservations.filter((r) => r.location === "MG2")}
            />
          </TabsContent>

          <TabsContent value="all">
            <AdminDashboardContent
              location="Todos"
              reservationStats={reservationStats[0]}
              vehicleStats={vehicleStats[0]}
              userStats={userStats[0]}
              recentReservations={recentReservations}
            />
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  )
}
