import { requireAdmin } from "@/lib/auth"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ResetSystem } from "./reset-system"

export default async function SettingsPage() {
  const user = await requireAdmin()

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Configurações do Sistema</h1>
          <p className="text-muted-foreground">Gerencie as configurações avançadas do sistema</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Resetar Sistema</CardTitle>
              <CardDescription>
                Remove todas as reservas e redefine o status dos veículos. Os usuários cadastrados serão mantidos.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResetSystem />
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}
