"use client"
import { useState, useEffect, useMemo } from "react"
import React from "react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  AlertCircle,
  Search,
  CheckCircle,
  XCircle,
  ArrowRightCircle,
  Pencil,
  CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Save,
} from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  format,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  addWeeks,
  subWeeks,
  parseISO,
  isValid,
  addMonths,
  subMonths,
  startOfMonth,
  endOfMonth,
  isSameMonth,
  isSameDay,
  getYear,
  setYear,
  getMonth,
  setMonth,
  isWithinInterval,
  addYears,
  subYears,
  getDay,
} from "date-fns"
import { ptBR } from "date-fns/locale"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { cn } from "@/lib/utils"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface Reservation {
  id: number
  reservation_code: string
  requester_name: string
  pickup_date: string
  return_date: string
  pickup_time: string
  return_time: string
  location: string
  status: string
  vehicle_model: string
  vehicle_plate: string
  reason: string
  user_name: string
  user_email: string
  vehicle_id: number
  cost_center: string
  rejection_reason?: string
}

interface Vehicle {
  id: number
  model: string
  plate: string
  location: string
}

interface AgendaViewTabularProps {
  initialReservations: Reservation[]
}

export function AgendaViewTabular({ initialReservations }: AgendaViewTabularProps) {
  const [reservations, setReservations] = useState<Reservation[]>(initialReservations)
  const [vehicles, setVehicles] = useState<Vehicle[]>([])
  const [filteredVehicles, setFilteredVehicles] = useState<Vehicle[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [filterLocation, setFilterLocation] = useState<string>("")
  const [filterVehicleId, setFilterVehicleId] = useState<string>("")
  const [error, setError] = useState("")
  const [currentDate, setCurrentDate] = useState<Date>(new Date())
  const [isLoading, setIsLoading] = useState(false)
  const [selectedReservation, setSelectedReservation] = useState<Reservation | null>(null)
  const [actionLoading, setActionLoading] = useState(false)
  const [successMessage, setSuccessMessage] = useState("")
  const [isRejeicaoDialogOpen, setIsRejeicaoDialogOpen] = useState<boolean>(false)
  const [reservaParaRejeitar, setReservaParaRejeitar] = useState<Reservation | null>(null)
  const [justificativaRejeicao, setJustificativaRejeicao] = useState<string>("")
  const [isEditDialogOpen, setIsEditDialogOpen] = useState<boolean>(false)
  const [reservaParaEditar, setReservaParaEditar] = useState<Reservation | null>(null)
  const [editForm, setEditForm] = useState({
    pickupDate: new Date(),
    returnDate: new Date(),
    pickupTime: "",
    returnTime: "",
    reason: "",
  })
  const [isCalendarDialogOpen, setIsCalendarDialogOpen] = useState(false)
  const [calendarDate, setCalendarDate] = useState<Date>(new Date())
  const [calendarYear, setCalendarYear] = useState<number>(new Date().getFullYear())
  const [calendarMonth, setCalendarMonth] = useState<number>(new Date().getMonth())

  // Horários padrão para exibição
  const timeSlots = ["08:00", "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00"]

  // Função para buscar reservas atualizadas
  const fetchReservations = async () => {
    try {
      setIsLoading(true)
      // Modificado para incluir reservas com status específicos
      const response = await fetch("/api/reservations?status=pendente,em_andamento,concluida")
      if (!response.ok) {
        throw new Error("Erro ao buscar reservas")
      }
      const data = await response.json()

      // Garantir que as datas estão no formato correto
      const processedData = data.map((res: Reservation) => ({
        ...res,
        pickup_date: res.pickup_date,
        return_date: res.return_date,
      }))

      console.log("Reservas carregadas:", processedData)
      setReservations(processedData)
    } catch (err: any) {
      console.error("Erro ao buscar reservas:", err)
      setError(err.message)
    } finally {
      setIsLoading(false)
    }
  }

  // Busca inicial e configuração de atualização periódica
  useEffect(() => {
    fetchReservations()

    // Configura intervalo para atualizações a cada 2 minutos
    const interval = setInterval(fetchReservations, 120000)

    // Limpa o intervalo quando o componente é desmontado
    return () => clearInterval(interval)
  }, [])

  // Buscar todos os veículos
  useEffect(() => {
    const fetchVehicles = async () => {
      try {
        const response = await fetch("/api/vehicles")
        if (!response.ok) {
          throw new Error("Erro ao buscar veículos")
        }
        const data = await response.json()
        setVehicles(data)
      } catch (err: any) {
        console.error("Erro ao buscar veículos:", err)
        setError(err.message)
      }
    }

    fetchVehicles()
  }, [])

  // Filtrar veículos por localização
  useEffect(() => {
    if (filterLocation) {
      const filtered = vehicles.filter((vehicle) => vehicle.location === filterLocation)
      setFilteredVehicles(filtered)

      // Limpa o filtro de veículo se o local mudar
      setFilterVehicleId("")
    } else {
      setFilteredVehicles([])
    }
  }, [filterLocation, vehicles])

  // Iniciar reserva diretamente (sem aprovação)
  const handleStartReservation = async (id: number) => {
    setActionLoading(true)
    try {
      const response = await fetch(`/api/reservations/${id}/start`, {
        method: "POST",
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.error || "Erro ao iniciar reserva")
      }

      // Atualiza a lista de reservas
      setReservations(
        reservations.map((reservation) =>
          reservation.id === id ? { ...reservation, status: "em_andamento" } : reservation,
        ),
      )

      setSuccessMessage("Reserva iniciada com sucesso!")
      setTimeout(() => setSuccessMessage(""), 3000)

      // Fecha o diálogo de detalhes
      setSelectedReservation(null)

      // Atualiza a lista de reservas
      fetchReservations()
    } catch (err: any) {
      setError(err.message)
    } finally {
      setActionLoading(false)
    }
  }

  // Concluir a reserva
  const handleCompleteReservation = async (id: number) => {
    setActionLoading(true)
    try {
      const response = await fetch(`/api/reservations/${id}/complete`, {
        method: "POST",
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.error || "Erro ao concluir reserva")
      }

      // Atualiza a lista de reservas
      setReservations(
        reservations.map((reservation) =>
          reservation.id === id ? { ...reservation, status: "concluida" } : reservation,
        ),
      )

      setSuccessMessage("Reserva concluída com sucesso!")
      setTimeout(() => setSuccessMessage(""), 3000)

      // Fecha o diálogo de detalhes
      setSelectedReservation(null)

      // Atualiza a lista de reservas
      fetchReservations()
    } catch (err: any) {
      setError(err.message)
    } finally {
      setActionLoading(false)
    }
  }

  // Rejeitar reserva com justificativa
  const handleRejectWithJustification = async () => {
    if (!reservaParaRejeitar || !justificativaRejeicao.trim()) {
      setError("É necessário fornecer uma justificativa para rejeitar a reserva.")
      return
    }

    setActionLoading(true)
    try {
      const response = await fetch(`/api/reservations/${reservaParaRejeitar.id}/reject`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ justificativa: justificativaRejeicao }),
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.error || "Erro ao rejeitar reserva")
      }

      // Remove a reserva rejeitada da lista
      setReservations(reservations.filter((reservation) => reservation.id !== reservaParaRejeitar.id))

      setSuccessMessage("Reserva rejeitada com sucesso!")
      setTimeout(() => setSuccessMessage(""), 3000)

      // Fecha o diálogo de rejeição
      setIsRejeicaoDialogOpen(false)
      setReservaParaRejeitar(null)
      setJustificativaRejeicao("")

      // Fecha o diálogo de detalhes se estiver aberto
      setSelectedReservation(null)

      // Atualiza a lista de reservas
      fetchReservations()
    } catch (err: any) {
      setError(err.message)
    } finally {
      setActionLoading(false)
    }
  }

  // Abrir o diálogo de rejeição
  const openRejectDialog = (reservation: Reservation) => {
    setReservaParaRejeitar(reservation)
    setIsRejeicaoDialogOpen(true)
  }

  // Abrir o diálogo de edição
  const openEditDialog = (reservation: Reservation) => {
    setReservaParaEditar(reservation)

    try {
      // Converter strings de data para objetos Date com validação
      let pickupDate = new Date()
      let returnDate = new Date()

      if (reservation.pickup_date && typeof reservation.pickup_date === "string") {
        const parsedDate = parseISO(reservation.pickup_date)
        if (isValid(parsedDate)) {
          pickupDate = parsedDate
        }
      }

      if (reservation.return_date && typeof reservation.return_date === "string") {
        const parsedDate = parseISO(reservation.return_date)
        if (isValid(parsedDate)) {
          returnDate = parsedDate
        }
      }

      setEditForm({
        pickupDate,
        returnDate,
        pickupTime: reservation.pickup_time || "",
        returnTime: reservation.return_time || "",
        reason: reservation.reason || "",
      })
    } catch (error) {
      console.error("Erro ao processar datas:", error)
      // Usar datas atuais como fallback
      setEditForm({
        pickupDate: new Date(),
        returnDate: new Date(),
        pickupTime: reservation.pickup_time || "",
        returnTime: reservation.return_time || "",
        reason: reservation.reason || "",
      })
    }

    setIsEditDialogOpen(true)
  }

  // Salvar a edição da reserva
  const handleSaveEdit = async () => {
    if (!reservaParaEditar) return

    setActionLoading(true)
    try {
      // Formatar as datas para o formato esperado pela API
      const formattedPickupDate = format(editForm.pickupDate, "yyyy-MM-dd")
      const formattedReturnDate = format(editForm.returnDate, "yyyy-MM-dd")

      const response = await fetch(`/api/reservations/${reservaParaEditar.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          requesterName: reservaParaEditar.requester_name,
          costCenter: reservaParaEditar.cost_center,
          pickupDate: formattedPickupDate,
          returnDate: formattedReturnDate,
          pickupTime: editForm.pickupTime,
          returnTime: editForm.returnTime,
          vehicleId: reservaParaEditar.vehicle_id,
          location: reservaParaEditar.location,
          reason: editForm.reason,
        }),
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.error || "Erro ao editar reserva")
      }

      setSuccessMessage("Reserva editada com sucesso!")
      setTimeout(() => setSuccessMessage(""), 3000)

      // Fecha o diálogo de edição
      setIsEditDialogOpen(false)
      setReservaParaEditar(null)

      // Atualiza a lista de reservas
      fetchReservations()
    } catch (err: any) {
      setError(err.message)
    } finally {
      setActionLoading(false)
    }
  }

  // Navegar para a semana anterior
  const goToPreviousWeek = () => {
    setCurrentDate(subWeeks(currentDate, 1))
  }

  // Navegar para a próxima semana
  const goToNextWeek = () => {
    setCurrentDate(addWeeks(currentDate, 1))
  }

  // Ir para a semana atual
  const goToCurrentWeek = () => {
    setCurrentDate(new Date())
  }

  // Navegar para o mês anterior no calendário
  const goToPreviousMonth = () => {
    setCalendarDate(subMonths(calendarDate, 1))
    setCalendarMonth(getMonth(subMonths(calendarDate, 1)))
  }

  // Navegar para o próximo mês no calendário
  const goToNextMonth = () => {
    setCalendarDate(addMonths(calendarDate, 1))
    setCalendarMonth(getMonth(addMonths(calendarDate, 1)))
  }

  // Navegar para o ano anterior no calendário
  const goToPreviousYear = () => {
    setCalendarDate(subYears(calendarDate, 1))
    setCalendarYear(getYear(subYears(calendarDate, 1)))
  }

  // Navegar para o próximo ano no calendário
  const goToNextYear = () => {
    setCalendarDate(addYears(calendarDate, 1))
    setCalendarYear(getYear(addYears(calendarDate, 1)))
  }

  // Selecionar uma data específica no calendário
  const selectDate = (date: Date) => {
    setCurrentDate(date)
    setIsCalendarDialogOpen(false)
  }

  // Filtra reservas com base nos filtros aplicados
  const filteredReservations = useMemo(() => {
    return reservations.filter((reservation) => {
      // Filtro de busca por nome do colaborador
      const matchesSearch = reservation.requester_name?.toLowerCase().includes(searchTerm.toLowerCase())

      // Filtro de localização
      const matchesLocation = !filterLocation || reservation.location === filterLocation

      // Filtro de veículo
      const matchesVehicle =
        !filterVehicleId || filterVehicleId === "all" || reservation.vehicle_id.toString() === filterVehicleId

      // Não mostrar reservas rejeitadas/canceladas
      const notRejected = reservation.status !== "cancelada"

      return matchesSearch && matchesLocation && matchesVehicle && notRejected
    })
  }, [reservations, searchTerm, filterLocation, filterVehicleId])

  // Obter os dias da semana atual
  const daysOfWeek = useMemo(() => {
    const start = startOfWeek(currentDate, { weekStartsOn: 1 }) // Semana começa na segunda-feira
    const end = endOfWeek(currentDate, { weekStartsOn: 1 })
    return eachDayOfInterval({ start, end })
  }, [currentDate])

  // Função para verificar se uma reserva está ativa em um determinado dia e horário
  const getReservationForDayAndTime = (day: Date, timeSlot: string, vehicleId: number) => {
    const dayStr = format(day, "yyyy-MM-dd")
    const [hours, minutes] = timeSlot.split(":")
    const timeInMinutes = Number.parseInt(hours) * 60 + Number.parseInt(minutes)

    return filteredReservations.find((reservation) => {
      try {
        if (reservation.vehicle_id !== vehicleId) return false
        if (!reservation.pickup_date || !reservation.return_date) return false
        if (!reservation.pickup_time || !reservation.return_time) return false

        // Verifica se o dia está dentro do período de reserva
        const isInDateRange = dayStr >= reservation.pickup_date && dayStr <= reservation.return_date

        if (!isInDateRange) return false

        // Verifica se o horário está dentro do período de reserva
        // Convertemos os horários para minutos para facilitar a comparação
        const [pickupHours, pickupMinutes] = reservation.pickup_time.split(":")
        const [returnHours, returnMinutes] = reservation.return_time.split(":")

        const pickupTimeInMinutes = Number.parseInt(pickupHours) * 60 + Number.parseInt(pickupMinutes)
        const returnTimeInMinutes = Number.parseInt(returnHours) * 60 + Number.parseInt(returnMinutes)

        // Se for o primeiro dia da reserva, verificamos se o horário é >= ao horário de retirada
        if (dayStr === reservation.pickup_date) {
          return timeInMinutes >= pickupTimeInMinutes
        }

        // Se for o último dia da reserva, verificamos se o horário é <= ao horário de devolução
        if (dayStr === reservation.return_date) {
          return timeInMinutes <= returnTimeInMinutes
        }

        // Se for um dia entre o primeiro e o último, a reserva está ativa durante todo o dia
        return true
      } catch (error) {
        console.error("Erro ao verificar reserva:", error)
        return false
      }
    })
  }

  // Função para obter a cor de fundo baseada no status da reserva
  const getStatusColor = (status: string) => {
    switch (status) {
      case "pendente":
        return "bg-yellow-100"
      case "em_andamento":
        return "bg-blue-100"
      case "concluida":
        return "bg-green-100"
      default:
        return "bg-gray-100"
    }
  }

  // Renderizar o calendário personalizado
  const renderCustomCalendar = () => {
    const firstDayOfMonth = startOfMonth(calendarDate)
    const lastDayOfMonth = endOfMonth(calendarDate)
    const daysInMonth = eachDayOfInterval({ start: firstDayOfMonth, end: lastDayOfMonth })

    // Ajustar para começar na segunda-feira (0 = segunda, 1 = terça, etc.)
    let firstDayOfWeek = getDay(firstDayOfMonth)
    firstDayOfWeek = firstDayOfWeek === 0 ? 6 : firstDayOfWeek - 1 // Converter para começar na segunda-feira

    // Criar array com células vazias para os dias antes do primeiro dia do mês
    const emptyDays = Array(firstDayOfWeek).fill(null)

    // Combinar dias vazios com os dias do mês
    const allDays = [...emptyDays, ...daysInMonth]

    // Dias da semana começando na segunda-feira
    const weekDays = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"]

    // Anos para seleção (10 anos para trás e 10 anos para frente)
    const currentYear = new Date().getFullYear()
    const years = Array.from({ length: 21 }, (_, i) => currentYear - 10 + i)

    // Meses para seleção
    const months = [
      "Janeiro",
      "Fevereiro",
      "Março",
      "Abril",
      "Maio",
      "Junho",
      "Julho",
      "Agosto",
      "Setembro",
      "Outubro",
      "Novembro",
      "Dezembro",
    ]

    return (
      <div className="p-4 bg-white rounded-lg shadow-lg">
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={goToPreviousYear}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Select
              value={calendarYear.toString()}
              onValueChange={(value) => {
                const newYear = Number.parseInt(value)
                setCalendarYear(newYear)
                setCalendarDate(setYear(calendarDate, newYear))
              }}
            >
              <SelectTrigger className="w-[100px]">
                <SelectValue>{calendarYear}</SelectValue>
              </SelectTrigger>
              <SelectContent>
                {years.map((year) => (
                  <SelectItem key={year} value={year.toString()}>
                    {year}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" onClick={goToNextYear}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>

          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={goToPreviousMonth}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Select
              value={calendarMonth.toString()}
              onValueChange={(value) => {
                const newMonth = Number.parseInt(value)
                setCalendarMonth(newMonth)
                setCalendarDate(setMonth(calendarDate, newMonth))
              }}
            >
              <SelectTrigger className="w-[120px]">
                <SelectValue>{months[calendarMonth]}</SelectValue>
              </SelectTrigger>
              <SelectContent>
                {months.map((month, index) => (
                  <SelectItem key={month} value={index.toString()}>
                    {month}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" onClick={goToNextMonth}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-1">
          {weekDays.map((day) => (
            <div key={day} className="text-center font-medium text-sm py-1">
              {day}
            </div>
          ))}

          {allDays.map((day, index) => {
            if (!day) {
              return <div key={`empty-${index}`} className="h-10" />
            }

            const isToday = isSameDay(day, new Date())
            const isCurrentMonth = isSameMonth(day, calendarDate)
            const hasReservations = filteredReservations.some((reservation) => {
              try {
                if (!reservation.pickup_date || !reservation.return_date) return false
                const pickupDate = parseISO(reservation.pickup_date)
                const returnDate = parseISO(reservation.return_date)
                return isWithinInterval(day, { start: pickupDate, end: returnDate })
              } catch (error) {
                return false
              }
            })

            return (
              <Button
                key={day.toString()}
                variant="ghost"
                className={cn(
                  "h-10 w-full rounded-full",
                  isToday ? "bg-primary text-primary-foreground" : "",
                  !isCurrentMonth ? "text-muted-foreground opacity-50" : "",
                  hasReservations ? "border-2 border-primary" : "",
                )}
                onClick={() => selectDate(day)}
              >
                {format(day, "d")}
              </Button>
            )
          })}
        </div>

        <div className="mt-4 flex justify-center">
          <Button onClick={() => selectDate(new Date())}>Hoje</Button>
        </div>
      </div>
    )
  }

  // Renderizar a tabela de agenda
  const renderAgendaTable = () => {
    // Obter veículos filtrados ou todos os veículos se não houver filtro
    const vehiclesToShow =
      filterVehicleId && filterVehicleId !== "all"
        ? filteredVehicles.filter((v) => v.id.toString() === filterVehicleId)
        : filteredVehicles.length > 0
          ? filteredVehicles
          : []

    if (vehiclesToShow.length === 0) {
      return (
        <div className="border rounded-md p-8 text-center">
          <p className="text-muted-foreground">Selecione um local e veículo para visualizar a agenda.</p>
        </div>
      )
    }

    return (
      <div className="border rounded-md overflow-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-24 bg-gray-100 font-bold">DATA</TableHead>
              <TableHead className="w-20 bg-gray-100 font-bold">HORÁRIO</TableHead>
              {vehiclesToShow.map((vehicle) => (
                <React.Fragment key={vehicle.id}>
                  <TableHead colSpan={2} className="text-center bg-primary/20 font-bold">
                    {vehicle.model} ({vehicle.plate})
                  </TableHead>
                </React.Fragment>
              ))}
            </TableRow>
            <TableRow>
              <TableHead></TableHead>
              <TableHead></TableHead>
              {vehiclesToShow.map((vehicle) => (
                <React.Fragment key={vehicle.id}>
                  <TableHead className="bg-gray-50 font-medium">COLABORADOR</TableHead>
                  <TableHead className="bg-gray-50 font-medium">MOTIVO</TableHead>
                </React.Fragment>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {daysOfWeek.map((day) => (
              <React.Fragment key={day.toString()}>
                {timeSlots.map((timeSlot, timeIndex) => (
                  <TableRow
                    key={`${day.toString()}-${timeSlot}`}
                    className={timeIndex % 2 === 0 ? "bg-gray-50/50" : ""}
                  >
                    {timeIndex === 0 && (
                      <TableCell rowSpan={timeSlots.length} className="font-medium bg-gray-100 text-center">
                        <div className="font-bold">{format(day, "EEEE", { locale: ptBR })}</div>
                        <div>{format(day, "d 'de' MMMM 'de' yyyy", { locale: ptBR })}</div>
                      </TableCell>
                    )}
                    <TableCell className="font-medium text-center">{timeSlot}</TableCell>

                    {vehiclesToShow.map((vehicle) => {
                      const reservation = getReservationForDayAndTime(day, timeSlot, vehicle.id)
                      const bgColor = reservation ? getStatusColor(reservation.status) : ""

                      return (
                        <React.Fragment key={`${day.toString()}-${timeSlot}-${vehicle.id}`}>
                          <TableCell
                            className={cn(bgColor, "cursor-pointer hover:opacity-80")}
                            onClick={() => reservation && setSelectedReservation(reservation)}
                          >
                            {reservation?.requester_name || ""}
                          </TableCell>
                          <TableCell
                            className={cn(bgColor, "cursor-pointer hover:opacity-80")}
                            onClick={() => reservation && setSelectedReservation(reservation)}
                          >
                            {reservation?.reason || ""}
                          </TableCell>
                        </React.Fragment>
                      )
                    })}
                  </TableRow>
                ))}
              </React.Fragment>
            ))}
          </TableBody>
        </Table>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {successMessage && (
        <Alert className="bg-green-100 border-green-200">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-600">{successMessage}</AlertDescription>
        </Alert>
      )}

      <div className="flex flex-col gap-4">
        {/* Filtros */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="space-y-2">
            <label htmlFor="location-filter" className="text-sm font-medium">
              Local
            </label>
            <Select value={filterLocation} onValueChange={setFilterLocation}>
              <SelectTrigger id="location-filter">
                <SelectValue placeholder="Selecione um local" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="MG1">MG1</SelectItem>
                <SelectItem value="MG2">MG2</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label htmlFor="vehicle-filter" className="text-sm font-medium">
              Veículo
            </label>
            <Select
              value={filterVehicleId}
              onValueChange={setFilterVehicleId}
              disabled={!filterLocation || filteredVehicles.length === 0}
            >
              <SelectTrigger id="vehicle-filter">
                <SelectValue
                  placeholder={
                    !filterLocation
                      ? "Selecione um local primeiro"
                      : filteredVehicles.length === 0
                        ? "Nenhum veículo disponível"
                        : "Todos os veículos"
                  }
                />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os veículos</SelectItem>
                {filteredVehicles.map((vehicle) => (
                  <SelectItem key={vehicle.id} value={vehicle.id.toString()}>
                    {vehicle.model} - {vehicle.plate}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label htmlFor="week-picker" className="text-sm font-medium">
              Semana
            </label>
            <div className="flex gap-2">
              <Button variant="outline" size="icon" onClick={goToPreviousWeek} title="Semana anterior">
                <ChevronLeft className="h-4 w-4" />
              </Button>

              <Button
                id="week-picker"
                variant="outline"
                className="w-full justify-start text-left font-normal"
                onClick={() => setIsCalendarDialogOpen(true)}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                <span className="font-medium">
                  {format(daysOfWeek[0], "dd/MM/yyyy")} - {format(daysOfWeek[6], "dd/MM/yyyy")}
                </span>
              </Button>

              <Button variant="outline" size="icon" onClick={goToNextWeek} title="Próxima semana">
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <label htmlFor="search-filter" className="text-sm font-medium">
              Buscar Colaborador
            </label>
            <div className="relative">
              <Input
                id="search-filter"
                placeholder="Buscar por colaborador..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8"
              />
              <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            </div>
          </div>
        </div>

        {/* Legenda de status */}
        <div className="flex flex-wrap gap-4 items-center">
          <span className="text-sm font-medium">Status:</span>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-yellow-400 mr-1"></div>
            <span className="text-sm">Pendente</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-green-400 mr-1"></div>
            <span className="text-sm">Concluída</span>
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="border rounded-md p-8 text-center">
          <p className="text-muted-foreground">Carregando agenda...</p>
        </div>
      ) : !filterLocation ? (
        <div className="border rounded-md p-8 text-center">
          <p className="text-muted-foreground">Selecione um local para visualizar a agenda.</p>
        </div>
      ) : (
        renderAgendaTable()
      )}

      {/* Rodapé */}
      <div className="text-center text-sm text-muted-foreground mt-8 pt-4 border-t">
        © 2025 Lorena Oliveira - Todos os direitos reservados.
      </div>

      {/* Diálogo de calendário personalizado */}
      <Dialog open={isCalendarDialogOpen} onOpenChange={setIsCalendarDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Selecionar Data</DialogTitle>
            <DialogDescription>Escolha uma data para visualizar na agenda</DialogDescription>
          </DialogHeader>
          {renderCustomCalendar()}
        </DialogContent>
      </Dialog>

      {/* Diálogo de detalhes da reserva */}
      {selectedReservation && (
        <Dialog open={!!selectedReservation} onOpenChange={(open) => !open && setSelectedReservation(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Detalhes da Reserva</DialogTitle>
              <DialogDescription>Código: {selectedReservation.reservation_code}</DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium">Veículo</h4>
                  <p>
                    {selectedReservation.vehicle_model} ({selectedReservation.vehicle_plate})
                  </p>
                </div>
                <div>
                  <h4 className="font-medium">Status</h4>
                  <div>
                    <Badge className={cn(getStatusColor(selectedReservation.status), "text-gray-800")}>
                      {selectedReservation.status === "pendente" ? "Pendente" : ""}
                      {selectedReservation.status === "em_andamento" ? "Em Andamento" : ""}
                      {selectedReservation.status === "concluida" ? "Concluída" : ""}
                    </Badge>
                  </div>
                </div>
                <div>
                  <h4 className="font-medium">Colaborador</h4>
                  <p>{selectedReservation.requester_name}</p>
                </div>
                <div>
                  <h4 className="font-medium">Centro de Custo</h4>
                  <p>{selectedReservation.cost_center}</p>
                </div>
                <div>
                  <h4 className="font-medium">Local</h4>
                  <p>{selectedReservation.location}</p>
                </div>
                <div>
                  <h4 className="font-medium">Período</h4>
                  <p>
                    {format(new Date(selectedReservation.pickup_date), "dd/MM/yyyy")} a{" "}
                    {format(new Date(selectedReservation.return_date), "dd/MM/yyyy")}
                  </p>
                </div>
                <div>
                  <h4 className="font-medium">Horário</h4>
                  <p>
                    {selectedReservation.pickup_time} às {selectedReservation.return_time}
                  </p>
                </div>
              </div>

              <div>
                <h4 className="font-medium">Motivo</h4>
                <p className="text-sm">{selectedReservation.reason}</p>
              </div>

              {selectedReservation.rejection_reason && (
                <div>
                  <h4 className="font-medium text-red-600">Justificativa de Rejeição</h4>
                  <p className="text-sm text-red-600">{selectedReservation.rejection_reason}</p>
                </div>
              )}
            </div>

            <DialogFooter>
              {selectedReservation && (
                <>
                  <Button
                    variant="outline"
                    onClick={() => openEditDialog(selectedReservation)}
                    className="border-blue-200 text-blue-700 hover:bg-blue-50"
                  >
                    <Pencil className="mr-2 h-4 w-4" />
                    Editar Reserva
                  </Button>

                  {selectedReservation.status === "pendente" && (
                    <>
                      <Button
                        variant="outline"
                        onClick={() => openRejectDialog(selectedReservation)}
                        disabled={actionLoading}
                        className="border-red-200 text-red-700 hover:bg-red-50"
                      >
                        <XCircle className="mr-2 h-4 w-4" />
                        {actionLoading ? "Processando..." : "Rejeitar"}
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => handleStartReservation(selectedReservation.id)}
                        disabled={actionLoading}
                        className="border-primary text-primary hover:bg-primary/10"
                      >
                        <ArrowRightCircle className="mr-2 h-4 w-4" />
                        {actionLoading ? "Processando..." : "Iniciar Uso"}
                      </Button>
                    </>
                  )}

                  {selectedReservation.status === "em_andamento" && (
                    <Button
                      variant="outline"
                      onClick={() => handleCompleteReservation(selectedReservation.id)}
                      disabled={actionLoading}
                      className="border-green-200 text-green-700 hover:bg-green-50"
                    >
                      <CheckCircle className="mr-2 h-4 w-4" />
                      {actionLoading ? "Processando..." : "Concluir Reserva"}
                    </Button>
                  )}

                  <Button variant="outline" onClick={() => setSelectedReservation(null)}>
                    Fechar
                  </Button>
                </>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Diálogo de rejeição com justificativa */}
      <Dialog open={isRejeicaoDialogOpen} onOpenChange={setIsRejeicaoDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Rejeitar Reserva</DialogTitle>
            <DialogDescription>Por favor, forneça uma justificativa para a rejeição desta reserva.</DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="justificativa">Justificativa *</Label>
              <Textarea
                id="justificativa"
                value={justificativaRejeicao}
                onChange={(e) => setJustificativaRejeicao(e.target.value)}
                placeholder="Informe o motivo da rejeição..."
                className="min-h-[100px]"
                required
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsRejeicaoDialogOpen(false)
                setReservaParaRejeitar(null)
                setJustificativaRejeicao("")
              }}
            >
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={handleRejectWithJustification}
              disabled={!justificativaRejeicao.trim() || actionLoading}
            >
              {actionLoading ? "Rejeitando..." : "Rejeitar Reserva"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo de edição de reserva */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Editar Reserva</DialogTitle>
            <DialogDescription>
              {reservaParaEditar && `Código: ${reservaParaEditar.reservation_code}`}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Data de Retirada *</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !editForm.pickupDate && "text-muted-foreground",
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {editForm.pickupDate
                        ? format(editForm.pickupDate, "dd/MM/yyyy", { locale: ptBR })
                        : "Selecione uma data"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={editForm.pickupDate}
                      onSelect={(date) => date && setEditForm({ ...editForm, pickupDate: date })}
                      initialFocus
                      locale={ptBR}
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label>Data de Devolução *</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !editForm.returnDate && "text-muted-foreground",
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {editForm.returnDate
                        ? format(editForm.returnDate, "dd/MM/yyyy", { locale: ptBR })
                        : "Selecione uma data"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={editForm.returnDate}
                      onSelect={(date) => date && setEditForm({ ...editForm, returnDate: date })}
                      initialFocus
                      disabled={(date) => {
                        if (editForm.pickupDate) {
                          const pickupCopy = new Date(editForm.pickupDate)
                          pickupCopy.setHours(0, 0, 0, 0)
                          return date < pickupCopy
                        }
                        return false
                      }}
                      locale={ptBR}
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label htmlFor="pickupTime">Horário de Retirada *</Label>
                <Input
                  id="pickupTime"
                  type="time"
                  value={editForm.pickupTime}
                  onChange={(e) => setEditForm({ ...editForm, pickupTime: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="returnTime">Horário de Devolução *</Label>
                <Input
                  id="returnTime"
                  type="time"
                  value={editForm.returnTime}
                  onChange={(e) => setEditForm({ ...editForm, returnTime: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="reason">Motivo da Reserva *</Label>
              <Textarea
                id="reason"
                value={editForm.reason}
                onChange={(e) => setEditForm({ ...editForm, reason: e.target.value })}
                required
                className="min-h-[100px]"
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsEditDialogOpen(false)
                setReservaParaEditar(null)
              }}
            >
              Cancelar
            </Button>
            <Button onClick={handleSaveEdit} disabled={actionLoading} className="gap-2">
              <Save className="h-4 w-4" />
              {actionLoading ? "Salvando..." : "Salvar Alterações"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
