"use client"
import { useState, useEffect, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  AlertCircle,
  Search,
  CheckCircle,
  XCircle,
  ArrowRightCircle,
  Pencil,
  CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Clock,
  Save,
} from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  format,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isSameMonth,
  isSameDay,
  addMonths,
  subMonths,
  getDay,
  parseISO,
  isValid,
  isWithinInterval,
} from "date-fns"
import { ptBR } from "date-fns/locale"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { cn } from "@/lib/utils"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"

interface Reservation {
  id: number
  reservation_code: string
  requester_name: string
  pickup_date: string
  return_date: string
  pickup_time: string
  return_time: string
  location: string
  status: string
  vehicle_model: string
  vehicle_plate: string
  reason: string
  user_name: string
  user_email: string
  vehicle_id: number
  cost_center: string
  rejection_reason?: string
}

interface Vehicle {
  id: number
  model: string
  plate: string
  location: string
}

interface AgendaViewProps {
  initialReservations: Reservation[]
}

export function AgendaView({ initialReservations }: AgendaViewProps) {
  const [reservations, setReservations] = useState<Reservation[]>(initialReservations)
  const [vehicles, setVehicles] = useState<Vehicle[]>([])
  const [filteredVehicles, setFilteredVehicles] = useState<Vehicle[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [filterLocation, setFilterLocation] = useState<string>("")
  const [filterVehicleId, setFilterVehicleId] = useState<string>("")
  const [error, setError] = useState("")
  const [currentDate, setCurrentDate] = useState<Date>(new Date())
  const [isLoading, setIsLoading] = useState(false)
  const [selectedReservation, setSelectedReservation] = useState<Reservation | null>(null)
  const [actionLoading, setActionLoading] = useState(false)
  const [successMessage, setSuccessMessage] = useState("")
  const [isRejeicaoDialogOpen, setIsRejeicaoDialogOpen] = useState<boolean>(false)
  const [reservaParaRejeitar, setReservaParaRejeitar] = useState<Reservation | null>(null)
  const [justificativaRejeicao, setJustificativaRejeicao] = useState<string>("")
  const [isEditDialogOpen, setIsEditDialogOpen] = useState<boolean>(false)
  const [reservaParaEditar, setReservaParaEditar] = useState<Reservation | null>(null)
  const [editForm, setEditForm] = useState({
    pickupDate: new Date(),
    returnDate: new Date(),
    pickupTime: "",
    returnTime: "",
    reason: "",
  })

  // Função para buscar reservas atualizadas
  const fetchReservations = async () => {
    try {
      setIsLoading(true)
      // Modificado para incluir reservas com status específicos
      const response = await fetch("/api/reservations?status=pendente,em_andamento,concluida")
      if (!response.ok) {
        throw new Error("Erro ao buscar reservas")
      }
      const data = await response.json()

      // Garantir que as datas estão no formato correto
      const processedData = data.map((res: Reservation) => ({
        ...res,
        pickup_date: res.pickup_date,
        return_date: res.return_date,
      }))

      console.log("Reservas carregadas:", processedData)
      setReservations(processedData)
    } catch (err: any) {
      console.error("Erro ao buscar reservas:", err)
      setError(err.message)
    } finally {
      setIsLoading(false)
    }
  }

  // Busca inicial e configuração de atualização periódica
  useEffect(() => {
    fetchReservations()

    // Configura intervalo para atualizações a cada 2 minutos
    const interval = setInterval(fetchReservations, 120000)

    // Limpa o intervalo quando o componente é desmontado
    return () => clearInterval(interval)
  }, [])

  // Buscar todos os veículos
  useEffect(() => {
    const fetchVehicles = async () => {
      try {
        const response = await fetch("/api/vehicles")
        if (!response.ok) {
          throw new Error("Erro ao buscar veículos")
        }
        const data = await response.json()
        setVehicles(data)
      } catch (err: any) {
        console.error("Erro ao buscar veículos:", err)
        setError(err.message)
      }
    }

    fetchVehicles()
  }, [])

  // Filtrar veículos por localização
  useEffect(() => {
    if (filterLocation) {
      const filtered = vehicles.filter((vehicle) => vehicle.location === filterLocation)
      setFilteredVehicles(filtered)

      // Limpa o filtro de veículo se o local mudar
      setFilterVehicleId("")
    } else {
      setFilteredVehicles([])
    }
  }, [filterLocation, vehicles])

  // Iniciar reserva diretamente (sem aprovação)
  const handleStartReservation = async (id: number) => {
    setActionLoading(true)
    try {
      const response = await fetch(`/api/reservations/${id}/start`, {
        method: "POST",
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.error || "Erro ao iniciar reserva")
      }

      // Atualiza a lista de reservas
      setReservations(
        reservations.map((reservation) =>
          reservation.id === id ? { ...reservation, status: "em_andamento" } : reservation,
        ),
      )

      setSuccessMessage("Reserva iniciada com sucesso!")
      setTimeout(() => setSuccessMessage(""), 3000)

      // Fecha o diálogo de detalhes
      setSelectedReservation(null)

      // Atualiza a lista de reservas
      fetchReservations()
    } catch (err: any) {
      setError(err.message)
    } finally {
      setActionLoading(false)
    }
  }

  // Concluir a reserva
  const handleCompleteReservation = async (id: number) => {
    setActionLoading(true)
    try {
      const response = await fetch(`/api/reservations/${id}/complete`, {
        method: "POST",
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.error || "Erro ao concluir reserva")
      }

      // Atualiza a lista de reservas
      setReservations(
        reservations.map((reservation) =>
          reservation.id === id ? { ...reservation, status: "concluida" } : reservation,
        ),
      )

      setSuccessMessage("Reserva concluída com sucesso!")
      setTimeout(() => setSuccessMessage(""), 3000)

      // Fecha o diálogo de detalhes
      setSelectedReservation(null)

      // Atualiza a lista de reservas
      fetchReservations()
    } catch (err: any) {
      setError(err.message)
    } finally {
      setActionLoading(false)
    }
  }

  // Rejeitar reserva com justificativa
  const handleRejectWithJustification = async () => {
    if (!reservaParaRejeitar || !justificativaRejeicao.trim()) {
      setError("É necessário fornecer uma justificativa para rejeitar a reserva.")
      return
    }

    setActionLoading(true)
    try {
      const response = await fetch(`/api/reservations/${reservaParaRejeitar.id}/reject`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ justificativa: justificativaRejeicao }),
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.error || "Erro ao rejeitar reserva")
      }

      // Remove a reserva rejeitada da lista
      setReservations(reservations.filter((reservation) => reservation.id !== reservaParaRejeitar.id))

      setSuccessMessage("Reserva rejeitada com sucesso!")
      setTimeout(() => setSuccessMessage(""), 3000)

      // Fecha o diálogo de rejeição
      setIsRejeicaoDialogOpen(false)
      setReservaParaRejeitar(null)
      setJustificativaRejeicao("")

      // Fecha o diálogo de detalhes se estiver aberto
      setSelectedReservation(null)

      // Atualiza a lista de reservas
      fetchReservations()
    } catch (err: any) {
      setError(err.message)
    } finally {
      setActionLoading(false)
    }
  }

  // Abrir o diálogo de rejeição
  const openRejectDialog = (reservation: Reservation) => {
    setReservaParaRejeitar(reservation)
    setIsRejeicaoDialogOpen(true)
  }

  // Abrir o diálogo de edição
  const openEditDialog = (reservation: Reservation) => {
    setReservaParaEditar(reservation)

    try {
      // Converter strings de data para objetos Date com validação
      let pickupDate = new Date()
      let returnDate = new Date()

      if (reservation.pickup_date && typeof reservation.pickup_date === "string") {
        const parsedDate = parseISO(reservation.pickup_date)
        if (isValid(parsedDate)) {
          pickupDate = parsedDate
        }
      }

      if (reservation.return_date && typeof reservation.return_date === "string") {
        const parsedDate = parseISO(reservation.return_date)
        if (isValid(parsedDate)) {
          returnDate = parsedDate
        }
      }

      setEditForm({
        pickupDate,
        returnDate,
        pickupTime: reservation.pickup_time || "",
        returnTime: reservation.return_time || "",
        reason: reservation.reason || "",
      })
    } catch (error) {
      console.error("Erro ao processar datas:", error)
      // Usar datas atuais como fallback
      setEditForm({
        pickupDate: new Date(),
        returnDate: new Date(),
        pickupTime: reservation.pickup_time || "",
        returnTime: reservation.return_time || "",
        reason: reservation.reason || "",
      })
    }

    setIsEditDialogOpen(true)
  }

  // Salvar a edição da reserva
  const handleSaveEdit = async () => {
    if (!reservaParaEditar) return

    setActionLoading(true)
    try {
      // Formatar as datas para o formato esperado pela API
      const formattedPickupDate = format(editForm.pickupDate, "yyyy-MM-dd")
      const formattedReturnDate = format(editForm.returnDate, "yyyy-MM-dd")

      const response = await fetch(`/api/reservations/${reservaParaEditar.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          requesterName: reservaParaEditar.requester_name,
          costCenter: reservaParaEditar.cost_center,
          pickupDate: formattedPickupDate,
          returnDate: formattedReturnDate,
          pickupTime: editForm.pickupTime,
          returnTime: editForm.returnTime,
          vehicleId: reservaParaEditar.vehicle_id,
          location: reservaParaEditar.location,
          reason: editForm.reason,
        }),
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.error || "Erro ao editar reserva")
      }

      setSuccessMessage("Reserva editada com sucesso!")
      setTimeout(() => setSuccessMessage(""), 3000)

      // Fecha o diálogo de edição
      setIsEditDialogOpen(false)
      setReservaParaEditar(null)

      // Atualiza a lista de reservas
      fetchReservations()
    } catch (err: any) {
      setError(err.message)
    } finally {
      setActionLoading(false)
    }
  }

  // Navegar para o mês anterior
  const goToPreviousMonth = () => {
    setCurrentDate(subMonths(currentDate, 1))
  }

  // Navegar para o próximo mês
  const goToNextMonth = () => {
    setCurrentDate(addMonths(currentDate, 1))
  }

  // Ir para o mês atual
  const goToCurrentMonth = () => {
    setCurrentDate(new Date())
  }

  // Filtra reservas com base nos filtros aplicados
  const filteredReservations = useMemo(() => {
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    const todayStr = format(today, "yyyy-MM-dd")

    return reservations.filter((reservation) => {
      // Filtro de busca por nome do colaborador
      const matchesSearch = reservation.requester_name?.toLowerCase().includes(searchTerm.toLowerCase())

      // Filtro de localização
      const matchesLocation = !filterLocation || reservation.location === filterLocation

      // Filtro de veículo
      const matchesVehicle =
        !filterVehicleId || filterVehicleId === "all" || reservation.vehicle_id.toString() === filterVehicleId

      // Não mostrar reservas rejeitadas/canceladas
      const notRejected = reservation.status !== "cancelada"

      // Verificar se a reserva está no mês atual
      let isInCurrentMonth = false
      try {
        if (reservation.pickup_date && typeof reservation.pickup_date === "string") {
          const pickupDate = parseISO(reservation.pickup_date)
          if (isValid(pickupDate)) {
            isInCurrentMonth = isInCurrentMonth || isSameMonth(pickupDate, currentDate)
          }
        }

        if (reservation.return_date && typeof reservation.return_date === "string") {
          const returnDate = parseISO(reservation.return_date)
          if (isValid(returnDate)) {
            isInCurrentMonth = isInCurrentMonth || isSameMonth(returnDate, currentDate)
          }
        }
      } catch (error) {
        console.error("Erro ao processar datas para filtro:", error)
        return false
      }

      // Para reservas concluídas, verificar se ainda estão dentro do período de vigência
      let isValidConcluded = true
      if (reservation.status === "concluida" && reservation.return_date) {
        isValidConcluded = reservation.return_date >= todayStr
      }

      return matchesSearch && matchesLocation && matchesVehicle && notRejected && isInCurrentMonth && isValidConcluded
    })
  }, [reservations, searchTerm, filterLocation, filterVehicleId, currentDate])

  // Função para verificar se um dia tem reservas
  const getReservationsForDay = (day: Date) => {
    const dayStr = format(day, "yyyy-MM-dd")

    return filteredReservations.filter((reservation) => {
      try {
        if (!reservation.pickup_date || !reservation.return_date) return false

        // Corrigido: Verifica se o dia está dentro do período de reserva
        const pickupDate = parseISO(reservation.pickup_date)
        const returnDate = parseISO(reservation.return_date)

        return isWithinInterval(day, { start: pickupDate, end: returnDate })
      } catch (error) {
        console.error("Erro ao verificar reservas para o dia:", error)
        return false
      }
    })
  }

  // Função para obter a cor de fundo baseada no status da reserva
  const getStatusColor = (status: string) => {
    switch (status) {
      case "pendente":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "em_andamento":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "concluida":
        return "bg-purple-100 text-purple-800 border-purple-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  // Renderizar o calendário no estilo clássico
  const renderCalendar = () => {
    // Dias da semana começando na segunda-feira
    const weekDays = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]

    // Obter o primeiro dia do mês
    const firstDayOfMonth = startOfMonth(currentDate)

    // Obter o último dia do mês
    const lastDayOfMonth = endOfMonth(currentDate)

    // Obter o dia da semana do primeiro dia (0 = domingo, 1 = segunda, etc.)
    // Ajustar para começar na segunda-feira (0 = segunda, 1 = terça, etc.)
    let firstDayOfWeek = getDay(firstDayOfMonth)
    firstDayOfWeek = firstDayOfWeek === 0 ? 6 : firstDayOfWeek - 1 // Converter para começar na segunda-feira

    // Obter todos os dias do mês
    const daysInMonth = eachDayOfInterval({ start: firstDayOfMonth, end: lastDayOfMonth })

    // Criar array com células vazias para os dias antes do primeiro dia do mês
    const emptyDays = Array(firstDayOfWeek).fill(null)

    // Combinar dias vazios com os dias do mês
    const allDays = [...emptyDays, ...daysInMonth]

    return (
      <div className="border rounded-md overflow-hidden">
        <div className="bg-primary text-white p-4 flex justify-between items-center">
          <Button variant="ghost" size="sm" onClick={goToPreviousMonth} className="text-white hover:bg-primary/80">
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <h2 className="text-xl font-bold">{format(currentDate, "MMMM yyyy", { locale: ptBR })}</h2>
          <Button variant="ghost" size="sm" onClick={goToNextMonth} className="text-white hover:bg-primary/80">
            <ChevronRight className="h-5 w-5" />
          </Button>
        </div>

        <div className="grid grid-cols-7 bg-muted">
          {weekDays.map((day, index) => (
            <div key={index} className="p-2 text-center font-medium border-b">
              {day}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 bg-white">
          {allDays.map((day, index) => {
            if (!day) {
              // Célula vazia para os dias antes do início do mês
              return <div key={`empty-${index}`} className="p-2 border min-h-[100px]"></div>
            }

            const isToday = isSameDay(day, new Date())
            const dayReservations = getReservationsForDay(day)
            const isCurrentMonth = isSameMonth(day, currentDate)

            return (
              <div
                key={day.toString()}
                className={cn(
                  "p-2 border min-h-[100px] relative",
                  isToday ? "bg-primary/5" : "",
                  !isCurrentMonth ? "bg-gray-50 text-gray-400" : "",
                )}
              >
                <div
                  className={cn(
                    "absolute top-1 right-1 w-6 h-6 flex items-center justify-center rounded-full text-sm",
                    isToday ? "bg-primary text-white" : "text-gray-500",
                  )}
                >
                  {format(day, "d")}
                </div>

                <div className="mt-6 space-y-1">
                  {dayReservations.map((reservation) => (
                    <div
                      key={reservation.id}
                      className={cn("p-1 rounded text-xs cursor-pointer", getStatusColor(reservation.status))}
                      onClick={() => setSelectedReservation(reservation)}
                    >
                      <div className="font-medium">{reservation.vehicle_model}</div>
                      <div>{reservation.requester_name}</div>
                      <div className="flex items-center mt-1">
                        <Clock className="h-3 w-3 mr-1" />
                        <span>
                          {reservation.pickup_time} - {reservation.return_time}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )
          })}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {successMessage && (
        <Alert className="bg-green-100 border-green-200">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-600">{successMessage}</AlertDescription>
        </Alert>
      )}

      <div className="flex flex-col gap-4">
        {/* Filtros */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="space-y-2">
            <label htmlFor="location-filter" className="text-sm font-medium">
              Local
            </label>
            <Select value={filterLocation} onValueChange={setFilterLocation}>
              <SelectTrigger id="location-filter">
                <SelectValue placeholder="Selecione um local" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="MG1">MG1</SelectItem>
                <SelectItem value="MG2">MG2</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label htmlFor="vehicle-filter" className="text-sm font-medium">
              Veículo
            </label>
            <Select
              value={filterVehicleId}
              onValueChange={setFilterVehicleId}
              disabled={!filterLocation || filteredVehicles.length === 0}
            >
              <SelectTrigger id="vehicle-filter">
                <SelectValue
                  placeholder={
                    !filterLocation
                      ? "Selecione um local primeiro"
                      : filteredVehicles.length === 0
                        ? "Nenhum veículo disponível"
                        : "Todos os veículos"
                  }
                />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os veículos</SelectItem>
                {filteredVehicles.map((vehicle) => (
                  <SelectItem key={vehicle.id} value={vehicle.id.toString()}>
                    {vehicle.model} - {vehicle.plate}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label htmlFor="month-year-picker" className="text-sm font-medium">
              Mês e Ano
            </label>
            <div className="flex gap-2">
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    id="month-year-picker"
                    variant="outline"
                    className="w-full justify-start text-left font-normal"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(currentDate, "MMMM yyyy", { locale: ptBR })}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="month"
                    selected={currentDate}
                    onSelect={(date) => date && setCurrentDate(date)}
                    initialFocus
                    locale={ptBR}
                  />
                </PopoverContent>
              </Popover>

              <Button variant="outline" size="icon" onClick={goToCurrentMonth} title="Ir para o mês atual">
                <CalendarIcon className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <label htmlFor="search-filter" className="text-sm font-medium">
              Buscar Colaborador
            </label>
            <div className="relative">
              <Input
                id="search-filter"
                placeholder="Buscar por colaborador..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8"
              />
              <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            </div>
          </div>
        </div>

        {/* Legenda de status */}
        <div className="flex flex-wrap gap-4 items-center">
          <span className="text-sm font-medium">Status:</span>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-yellow-400 mr-1"></div>
            <span className="text-sm">Pendente</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-purple-400 mr-1"></div>
            <span className="text-sm">Concluída</span>
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="border rounded-md p-8 text-center">
          <p className="text-muted-foreground">Carregando agenda...</p>
        </div>
      ) : !filterLocation ? (
        <div className="border rounded-md p-8 text-center">
          <p className="text-muted-foreground">Selecione um local para visualizar a agenda.</p>
        </div>
      ) : (
        renderCalendar()
      )}

      {/* Diálogo de detalhes da reserva */}
      {selectedReservation && (
        <Dialog open={!!selectedReservation} onOpenChange={(open) => !open && setSelectedReservation(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Detalhes da Reserva</DialogTitle>
              <DialogDescription>Código: {selectedReservation.reservation_code}</DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium">Veículo</h4>
                  <p>
                    {selectedReservation.vehicle_model} ({selectedReservation.vehicle_plate})
                  </p>
                </div>
                <div>
                  <h4 className="font-medium">Status</h4>
                  <div>
                    <Badge className={cn(getStatusColor(selectedReservation.status))}>
                      {selectedReservation.status === "pendente" ? "Pendente" : ""}
                      {selectedReservation.status === "em_andamento" ? "Em Andamento" : ""}
                      {selectedReservation.status === "concluida" ? "Concluída" : ""}
                    </Badge>
                  </div>
                </div>
                <div>
                  <h4 className="font-medium">Colaborador</h4>
                  <p>{selectedReservation.requester_name}</p>
                </div>
                <div>
                  <h4 className="font-medium">Centro de Custo</h4>
                  <p>{selectedReservation.cost_center}</p>
                </div>
                <div>
                  <h4 className="font-medium">Local</h4>
                  <p>{selectedReservation.location}</p>
                </div>
                <div>
                  <h4 className="font-medium">Período</h4>
                  <p>
                    {format(new Date(selectedReservation.pickup_date), "dd/MM/yyyy")} a{" "}
                    {format(new Date(selectedReservation.return_date), "dd/MM/yyyy")}
                  </p>
                </div>
                <div>
                  <h4 className="font-medium">Horário</h4>
                  <p>
                    {selectedReservation.pickup_time} às {selectedReservation.return_time}
                  </p>
                </div>
              </div>

              <div>
                <h4 className="font-medium">Motivo</h4>
                <p className="text-sm">{selectedReservation.reason}</p>
              </div>

              {selectedReservation.rejection_reason && (
                <div>
                  <h4 className="font-medium text-red-600">Justificativa de Rejeição</h4>
                  <p className="text-sm text-red-600">{selectedReservation.rejection_reason}</p>
                </div>
              )}
            </div>

            <DialogFooter>
              {selectedReservation && (
                <>
                  <Button
                    variant="outline"
                    onClick={() => openEditDialog(selectedReservation)}
                    className="border-blue-200 text-blue-700 hover:bg-blue-50"
                  >
                    <Pencil className="mr-2 h-4 w-4" />
                    Editar Reserva
                  </Button>

                  {selectedReservation.status === "pendente" && (
                    <>
                      <Button
                        variant="outline"
                        onClick={() => openRejectDialog(selectedReservation)}
                        disabled={actionLoading}
                        className="border-red-200 text-red-700 hover:bg-red-50"
                      >
                        <XCircle className="mr-2 h-4 w-4" />
                        {actionLoading ? "Processando..." : "Rejeitar"}
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => handleStartReservation(selectedReservation.id)}
                        disabled={actionLoading}
                        className="border-primary text-primary hover:bg-primary/10"
                      >
                        <ArrowRightCircle className="mr-2 h-4 w-4" />
                        {actionLoading ? "Processando..." : "Iniciar Uso"}
                      </Button>
                    </>
                  )}

                  {selectedReservation.status === "em_andamento" && (
                    <Button
                      variant="outline"
                      onClick={() => handleCompleteReservation(selectedReservation.id)}
                      disabled={actionLoading}
                      className="border-green-200 text-green-700 hover:bg-green-50"
                    >
                      <CheckCircle className="mr-2 h-4 w-4" />
                      {actionLoading ? "Processando..." : "Concluir Reserva"}
                    </Button>
                  )}

                  <Button variant="outline" onClick={() => setSelectedReservation(null)}>
                    Fechar
                  </Button>
                </>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Diálogo de rejeição com justificativa */}
      <Dialog open={isRejeicaoDialogOpen} onOpenChange={setIsRejeicaoDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Rejeitar Reserva</DialogTitle>
            <DialogDescription>Por favor, forneça uma justificativa para a rejeição desta reserva.</DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="justificativa">Justificativa *</Label>
              <Textarea
                id="justificativa"
                value={justificativaRejeicao}
                onChange={(e) => setJustificativaRejeicao(e.target.value)}
                placeholder="Informe o motivo da rejeição..."
                className="min-h-[100px]"
                required
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsRejeicaoDialogOpen(false)
                setReservaParaRejeitar(null)
                setJustificativaRejeicao("")
              }}
            >
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={handleRejectWithJustification}
              disabled={!justificativaRejeicao.trim() || actionLoading}
            >
              {actionLoading ? "Rejeitando..." : "Rejeitar Reserva"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo de edição de reserva */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Editar Reserva</DialogTitle>
            <DialogDescription>
              {reservaParaEditar && `Código: ${reservaParaEditar.reservation_code}`}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Data de Retirada *</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !editForm.pickupDate && "text-muted-foreground",
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {editForm.pickupDate
                        ? format(editForm.pickupDate, "dd/MM/yyyy", { locale: ptBR })
                        : "Selecione uma data"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={editForm.returnDate}
                      onSelect={(date) => date && setEditForm({ ...editForm, returnDate: date })}
                      initialFocus
                      disabled={(date) => {
                        if (editForm.pickupDate) {
                          const pickupCopy = new Date(editForm.pickupDate)
                          pickupCopy.setHours(0, 0, 0, 0)
                          return date < pickupCopy
                        }
                        return false
                      }}
                      locale={ptBR}
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label htmlFor="pickupTime">Horário de Retirada *</Label>
                <Input
                  id="pickupTime"
                  type="time"
                  value={editForm.pickupTime}
                  onChange={(e) => setEditForm({ ...editForm, pickupTime: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="returnTime">Horário de Devolução *</Label>
                <Input
                  id="returnTime"
                  type="time"
                  value={editForm.returnTime}
                  onChange={(e) => setEditForm({ ...editForm, returnTime: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="reason">Motivo da Reserva *</Label>
              <Textarea
                id="reason"
                value={editForm.reason}
                onChange={(e) => setEditForm({ ...editForm, reason: e.target.value })}
                required
                className="min-h-[100px]"
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsEditDialogOpen(false)
                setReservaParaEditar(null)
              }}
            >
              Cancelar
            </Button>
            <Button onClick={handleSaveEdit} disabled={actionLoading} className="gap-2">
              <Save className="h-4 w-4" />
              {actionLoading ? "Salvando..." : "Salvar Alterações"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
