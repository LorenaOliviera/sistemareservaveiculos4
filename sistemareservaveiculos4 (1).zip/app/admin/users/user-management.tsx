"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, Plus, Pencil, Search, Trash2 } from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { useRouter } from "next/navigation"
import { formatDate } from "@/lib/utils"

interface User {
  id: number
  name: string
  email: string
  role: string
  created_at: string
  last_login: string | null
  status: boolean
}

interface UserManagementProps {
  initialUsers: User[]
  currentUser: User
}

export function UserManagement({ initialUsers, currentUser }: UserManagementProps) {
  const router = useRouter()
  const [users, setUsers] = useState<User[]>(initialUsers)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const [confirmDeleteDialogOpen, setConfirmDeleteDialogOpen] = useState(false)
  const [userToDelete, setUserToDelete] = useState<number | null>(null)

  // Estado para o formulário de usuário
  const [userForm, setUserForm] = useState({
    name: "",
    email: "",
    password: "",
    role: "solicitante",
  })

  // Estado para o usuário sendo editado
  const [editingUser, setEditingUser] = useState<User | null>(null)

  // Filtra usuários com base no termo de busca
  const filteredUsers = users.filter(
    (user) =>
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleAddUser = async () => {
    setError("")
    setLoading(true)

    try {
      // Validação do email
      if (!userForm.email.endsWith("@lenzing.com")) {
        throw new Error("Apenas emails do domínio @lenzing.com são permitidos")
      }

      const response = await fetch("/api/users", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(userForm),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Erro ao adicionar usuário")
      }

      // Adiciona o novo usuário à lista
      setUsers([...users, data.user])

      // Reseta o formulário
      setUserForm({
        name: "",
        email: "",
        password: "",
        role: "solicitante",
      })

      // Fecha o diálogo
      setIsAddDialogOpen(false)

      // Atualiza a página
      router.refresh()
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleEditUser = async () => {
    if (!editingUser) return

    setError("")
    setLoading(true)

    try {
      const response = await fetch(`/api/users/${editingUser.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: userForm.name,
          role: userForm.role,
        }),
      })

      if (!response.ok) {
        // Se a resposta não for ok, tenta obter o erro como JSON
        try {
          const errorData = await response.json()
          throw new Error(errorData.error || "Erro ao editar usuário")
        } catch (jsonError) {
          // Se não conseguir parsear como JSON, usa o texto da resposta
          const errorText = await response.text()
          throw new Error(`Erro ao editar usuário: ${errorText.substring(0, 100)}...`)
        }
      }

      const data = await response.json()

      // Atualiza o usuário na lista
      setUsers(
        users.map((user) =>
          user.id === editingUser.id ? { ...user, name: userForm.name, role: userForm.role } : user,
        ),
      )

      // Fecha o diálogo
      setIsEditDialogOpen(false)

      // Atualiza a página
      router.refresh()
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleToggleStatus = async (userId: number, currentStatus: boolean) => {
    try {
      // Não permite desativar o próprio usuário
      if (userId === currentUser.id) {
        setError("Você não pode desativar seu próprio usuário")
        return
      }

      const response = await fetch(`/api/users/${userId}/toggle-status`, {
        method: "POST",
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Erro ao alterar status do usuário")
      }

      // Atualiza o status do usuário na lista
      setUsers(users.map((user) => (user.id === userId ? { ...user, status: !currentStatus } : user)))

      // Atualiza a página
      router.refresh()
    } catch (err: any) {
      setError(err.message)
    }
  }

  const openEditDialog = (user: User) => {
    setEditingUser(user)
    setUserForm({
      name: user.name,
      email: user.email,
      password: "",
      role: user.role,
    })
    setIsEditDialogOpen(true)
  }

  const handleDeleteUser = async (userId: number) => {
    try {
      // Não permite excluir o próprio usuário
      if (userId === currentUser.id) {
        setError("Você não pode excluir seu próprio usuário")
        return
      }

      setLoading(true)
      const response = await fetch(`/api/users/${userId}`, {
        method: "DELETE",
      })

      // Tenta obter a resposta como JSON
      let errorMessage = "Erro ao excluir usuário"
      try {
        const data = await response.json()
        if (!response.ok) {
          errorMessage = data.error || errorMessage
          throw new Error(errorMessage)
        }

        // Remove o usuário da lista
        setUsers(users.filter((user) => user.id !== userId))

        // Fecha o diálogo de confirmação
        setConfirmDeleteDialogOpen(false)
        setUserToDelete(null)

        // Atualiza a página
        router.refresh()
      } catch (jsonError) {
        // Se não conseguir parsear como JSON, tenta obter o texto da resposta
        if (!response.ok) {
          const text = await response.text()
          throw new Error(`${errorMessage}: ${text.substring(0, 100)}...`)
        }
        throw jsonError
      }
    } catch (err: any) {
      console.error("Erro ao excluir usuário:", err)
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const openDeleteConfirmDialog = (userId: number) => {
    setUserToDelete(userId)
    setConfirmDeleteDialogOpen(true)
  }

  return (
    <div className="space-y-4">
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div className="relative w-full sm:w-64">
          <Input
            placeholder="Buscar usuário..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-8"
          />
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
        </div>

        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Adicionar Usuário
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Adicionar Usuário</DialogTitle>
              <DialogDescription>Preencha os dados do novo usuário</DialogDescription>
            </DialogHeader>

            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nome Completo</Label>
                <Input
                  id="name"
                  value={userForm.name}
                  onChange={(e) => setUserForm({ ...userForm, name: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="usuario@lenzing.com"
                  value={userForm.email}
                  onChange={(e) => setUserForm({ ...userForm, email: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Senha</Label>
                <Input
                  id="password"
                  type="password"
                  value={userForm.password}
                  onChange={(e) => setUserForm({ ...userForm, password: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="role">Tipo de Usuário</Label>
                <Select value={userForm.role} onValueChange={(value) => setUserForm({ ...userForm, role: value })}>
                  <SelectTrigger id="role">
                    <SelectValue placeholder="Selecione o tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="solicitante">Solicitante</SelectItem>
                    <SelectItem value="admin">Administrador</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="button" onClick={handleAddUser} disabled={loading}>
                {loading ? "Adicionando..." : "Adicionar"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Editar Usuário</DialogTitle>
              <DialogDescription>Atualize os dados do usuário</DialogDescription>
            </DialogHeader>

            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">Nome Completo</Label>
                <Input
                  id="edit-name"
                  value={userForm.name}
                  onChange={(e) => setUserForm({ ...userForm, name: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-email">Email</Label>
                <Input id="edit-email" type="email" value={userForm.email} disabled />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-role">Tipo de Usuário</Label>
                <Select
                  value={userForm.role}
                  onValueChange={(value) => setUserForm({ ...userForm, role: value })}
                  disabled={editingUser?.id === currentUser.id}
                >
                  <SelectTrigger id="edit-role">
                    <SelectValue placeholder="Selecione o tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="solicitante">Solicitante</SelectItem>
                    <SelectItem value="admin">Administrador</SelectItem>
                  </SelectContent>
                </Select>
                {editingUser?.id === currentUser.id && (
                  <p className="text-xs text-muted-foreground mt-1">
                    Você não pode alterar seu próprio tipo de usuário
                  </p>
                )}
              </div>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="button" onClick={handleEditUser} disabled={loading}>
                {loading ? "Salvando..." : "Salvar Alterações"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Data de Cadastro</TableHead>
              <TableHead>Último Acesso</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredUsers.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-4 text-muted-foreground">
                  Nenhum usuário encontrado.
                </TableCell>
              </TableRow>
            ) : (
              filteredUsers.map((user) => (
                <TableRow key={user.id}>
                  <TableCell className="font-medium">{user.name}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={user.role === "admin" ? "bg-primary/20 text-primary border-primary" : ""}
                    >
                      {user.role === "admin" ? "Administrador" : "Solicitante"}
                    </Badge>
                  </TableCell>
                  <TableCell>{formatDate(user.created_at)}</TableCell>
                  <TableCell>{user.last_login ? formatDate(user.last_login) : "Nunca"}</TableCell>
                  <TableCell>
                    <Switch
                      checked={user.status}
                      onCheckedChange={() => handleToggleStatus(user.id, user.status)}
                      disabled={user.id === currentUser.id}
                    />
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => openEditDialog(user)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => openDeleteConfirmDialog(user.id)}
                      disabled={user.id === currentUser.id}
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Diálogo de confirmação de exclusão */}
      <Dialog open={confirmDeleteDialogOpen} onOpenChange={setConfirmDeleteDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Confirmar Exclusão</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir este usuário? Esta ação não pode ser desfeita.
              <br />
              <br />
              <strong>Importante:</strong> As reservas passadas deste usuário serão mantidas, mas todas as reservas
              futuras serão canceladas automaticamente.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() => {
                setConfirmDeleteDialogOpen(false)
                setUserToDelete(null)
              }}
            >
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={() => userToDelete && handleDeleteUser(userToDelete)}
              disabled={loading}
            >
              {loading ? "Excluindo..." : "Excluir"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
