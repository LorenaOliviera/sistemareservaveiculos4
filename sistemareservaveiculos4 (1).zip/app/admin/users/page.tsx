import { requireAdmin } from "@/lib/auth"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { executeQuery } from "@/lib/db"
import { UserManagement } from "./user-management"

export default async function UsersPage() {
  const user = await requireAdmin()

  // Busca todos os usuários
  const users = await executeQuery(`
    SELECT id, name, email, role, created_at, last_login, status
    FROM users
    ORDER BY name ASC
  `)

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Gestão de Usuários</h1>
          <p className="text-muted-foreground">Gerencie os usuários do sistema de reserva de veículos</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Usuários</CardTitle>
            <CardDescription>Lista de todos os usuários cadastrados no sistema</CardDescription>
          </CardHeader>
          <CardContent>
            <UserManagement initialUsers={users} currentUser={user} />
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
