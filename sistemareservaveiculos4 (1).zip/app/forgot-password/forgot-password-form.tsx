"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, CheckCircle2 } from "lucide-react"

export function ForgotPasswordForm() {
  const [email, setEmail] = useState("")
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      // Validação do email
      if (!email.endsWith("@lenzing.com")) {
        throw new Error("Apenas emails do domínio @lenzing.com são permitidos")
      }

      // Simulação de envio de email de recuperação
      // Em um ambiente real, isso chamaria uma API
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Mostra mensagem de sucesso
      setSuccess(true)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="bg-primary/20 text-primary border-primary">
          <CheckCircle2 className="h-4 w-4" />
          <AlertDescription>
            Se o email estiver cadastrado, você receberá instruções para redefinir sua senha.
          </AlertDescription>
        </Alert>
      )}

      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          placeholder="seu.email@lenzing.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          disabled={success}
        />
      </div>

      <Button type="submit" className="w-full" disabled={loading || success}>
        {loading ? "Enviando..." : "Enviar instruções"}
      </Button>

      <div className="text-center">
        <p className="text-sm text-muted-foreground">
          Lembrou sua senha?{" "}
          <Link href="/login" className="font-medium text-primary hover:underline">
            Voltar para o login
          </Link>
        </p>
      </div>
    </form>
  )
}
