"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, CheckCircle2, CalendarIcon, Save } from "lucide-react"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format, parseISO } from "date-fns"
import { ptBR } from "date-fns/locale"
import { cn } from "@/lib/utils"
import { useRouter } from "next/navigation"

interface EditReservationProps {
  reservation: any
  onClose: () => void
  onSuccess: (updatedReservation: any) => void
}

export function EditReservation({ reservation, onClose, onSuccess }: EditReservationProps) {
  const router = useRouter()

  // Garantir que as datas sejam parseadas corretamente
  const [pickupDate, setPickupDate] = useState<Date | undefined>(() => {
    try {
      if (!reservation.pickup_date) return undefined
      return parseISO(reservation.pickup_date)
    } catch (e) {
      console.error("Erro ao parsear data de retirada:", e)
      return undefined
    }
  })

  const [returnDate, setReturnDate] = useState<Date | undefined>(() => {
    try {
      if (!reservation.return_date) return undefined
      return parseISO(reservation.return_date)
    } catch (e) {
      console.error("Erro ao parsear data de devolução:", e)
      return undefined
    }
  })

  const [pickupTime, setPickupTime] = useState(reservation.pickup_time || "")
  const [returnTime, setReturnTime] = useState(reservation.return_time || "")
  const [reason, setReason] = useState(reservation.reason || "")
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      // Validações
      if (!pickupDate || !returnDate) {
        throw new Error("Selecione as datas de retirada e devolução")
      }

      if (!pickupTime || !returnTime) {
        throw new Error("Selecione os horários de retirada e devolução")
      }

      if (pickupDate > returnDate) {
        throw new Error("A data de devolução deve ser posterior à data de retirada")
      }

      // Formatar as datas no formato correto para a API
      const formattedPickupDate = format(pickupDate, "yyyy-MM-dd")
      const formattedReturnDate = format(returnDate, "yyyy-MM-dd")

      console.log("Enviando dados para edição:", {
        pickupDate: formattedPickupDate,
        returnDate: formattedReturnDate,
        pickupTime,
        returnTime,
        reason,
      })

      // Incluir todos os campos necessários para a API
      const requestData = {
        requesterName: reservation.requester_name,
        costCenter: reservation.cost_center,
        pickupDate: formattedPickupDate,
        returnDate: formattedReturnDate,
        pickupTime,
        returnTime,
        vehicleId: reservation.vehicle_id,
        location: reservation.location,
        reason,
      }

      const response = await fetch(`/api/reservations/${reservation.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestData),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Erro ao atualizar reserva")
      }

      const data = await response.json()

      // Mostra mensagem de sucesso
      setSuccess(true)

      // Atualiza a reserva no componente pai com os valores corretos
      if (onSuccess) {
        const updatedReservation = {
          ...reservation,
          pickup_date: formattedPickupDate,
          return_date: formattedReturnDate,
          pickup_time: pickupTime,
          return_time: returnTime,
          reason: reason,
        }
        onSuccess(updatedReservation)
      }

      // Atualiza a página após 2 segundos
      setTimeout(() => {
        onClose()
        router.refresh()
      }, 2000)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="bg-primary/20 text-primary border-primary">
          <CheckCircle2 className="h-4 w-4" />
          <AlertDescription>Reserva atualizada com sucesso!</AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label>Data de Retirada *</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn("w-full justify-start text-left font-normal", !pickupDate && "text-muted-foreground")}
                disabled={success}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {pickupDate ? format(pickupDate, "dd/MM/yyyy", { locale: ptBR }) : "Selecione uma data"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={pickupDate}
                onSelect={(date) => {
                  if (date) {
                    setPickupDate(date)
                  }
                }}
                initialFocus
                disabled={(date) => {
                  // Permitir reservas a partir do dia atual
                  const today = new Date()
                  today.setHours(0, 0, 0, 0)
                  return date < today
                }}
                locale={ptBR}
              />
            </PopoverContent>
          </Popover>
        </div>

        <div className="space-y-2">
          <Label>Data de Devolução *</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn("w-full justify-start text-left font-normal", !returnDate && "text-muted-foreground")}
                disabled={success}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {returnDate ? format(returnDate, "dd/MM/yyyy", { locale: ptBR }) : "Selecione uma data"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={returnDate}
                onSelect={(date) => {
                  if (date) {
                    setReturnDate(date)
                  }
                }}
                initialFocus
                disabled={(date) => {
                  // Permitir devolução no mesmo dia da retirada
                  if (pickupDate) {
                    // Se a data de retirada estiver definida, a data de devolução deve ser igual ou posterior
                    const pickupCopy = new Date(pickupDate)
                    pickupCopy.setHours(0, 0, 0, 0)
                    return date < pickupCopy
                  }

                  const today = new Date()
                  today.setHours(0, 0, 0, 0)
                  return date < today
                }}
                locale={ptBR}
              />
            </PopoverContent>
          </Popover>
        </div>

        <div className="space-y-2">
          <Label htmlFor="pickupTime">Horário de Retirada *</Label>
          <Input
            id="pickupTime"
            type="time"
            value={pickupTime}
            onChange={(e) => setPickupTime(e.target.value)}
            required
            disabled={success}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="returnTime">Horário de Devolução *</Label>
          <Input
            id="returnTime"
            type="time"
            value={returnTime}
            onChange={(e) => setReturnTime(e.target.value)}
            required
            disabled={success}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="reason">Motivo da Reserva *</Label>
        <Textarea
          id="reason"
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          required
          className="min-h-[100px]"
          disabled={success}
        />
      </div>

      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onClose} disabled={loading || success}>
          Cancelar
        </Button>
        <Button type="submit" disabled={loading || success} className="gap-2">
          {loading ? (
            "Salvando..."
          ) : (
            <>
              <Save className="h-4 w-4" />
              Salvar Alterações
            </>
          )}
        </Button>
      </div>
    </form>
  )
}
