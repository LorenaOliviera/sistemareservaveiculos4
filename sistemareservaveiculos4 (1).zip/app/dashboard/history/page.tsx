import { requireAuth } from "@/lib/auth"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ReservationHistory } from "./reservation-history"

export default async function HistoryPage() {
  const user = await requireAuth()

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Histórico de Reservas</h1>
          <p className="text-muted-foreground">Visualize e gerencie suas reservas de veículos</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Minhas Reservas</CardTitle>
            <CardDescription>Aqui você pode visualizar, editar ou cancelar suas reservas</CardDescription>
          </CardHeader>
          <CardContent>
            <ReservationHistory />
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
