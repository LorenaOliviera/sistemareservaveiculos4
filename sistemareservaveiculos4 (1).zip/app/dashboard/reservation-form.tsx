"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, CheckCircle2, CalendarIcon } from "lucide-react"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { cn } from "@/lib/utils"

interface Vehicle {
  id: number
  plate: string
  model: string
  location: string
  status: string
}

interface ReservationFormProps {
  vehicles: Vehicle[]
  userId: number
}

export function ReservationForm({ vehicles, userId }: ReservationFormProps) {
  const router = useRouter()
  const [requesterName, setRequesterName] = useState("")
  const [costCenter, setCostCenter] = useState("")
  const [pickupDate, setPickupDate] = useState<Date | undefined>(undefined)
  const [returnDate, setReturnDate] = useState<Date | undefined>(undefined)
  const [pickupTime, setPickupTime] = useState("")
  const [returnTime, setReturnTime] = useState("")
  const [vehicleId, setVehicleId] = useState("")
  const [location, setLocation] = useState("")
  const [reason, setReason] = useState("")
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)
  const [loading, setLoading] = useState(false)
  const [reservationCode, setReservationCode] = useState("")
  const [availableVehicles, setAvailableVehicles] = useState<Vehicle[]>([])
  const [isLoadingVehicles, setIsLoadingVehicles] = useState(false)

  // Buscar veículos disponíveis quando as datas e local são selecionados
  useEffect(() => {
    if (pickupDate && returnDate && location) {
      fetchAvailableVehicles()
    } else {
      setAvailableVehicles([])
      setVehicleId("")
    }
  }, [pickupDate, returnDate, location])

  const fetchAvailableVehicles = async () => {
    if (!pickupDate || !returnDate || !location) return

    try {
      setIsLoadingVehicles(true)
      // Formatar as datas no formato correto para a API
      const formattedPickupDate = format(pickupDate, "yyyy-MM-dd")
      const formattedReturnDate = format(returnDate, "yyyy-MM-dd")

      console.log("Verificando veículos disponíveis para:", {
        location,
        pickupDate: formattedPickupDate,
        returnDate: formattedReturnDate,
      })

      const response = await fetch(
        `/api/vehicles/available?location=${location}&pickupDate=${formattedPickupDate}&returnDate=${formattedReturnDate}`,
      )

      if (!response.ok) {
        throw new Error("Erro ao verificar disponibilidade de veículos")
      }

      const data = await response.json()
      console.log("Veículos disponíveis:", data)
      setAvailableVehicles(data)

      // Se o veículo selecionado não estiver mais disponível, limpa a seleção
      if (vehicleId && !data.some((v: Vehicle) => v.id === Number(vehicleId))) {
        setVehicleId("")
      }
    } catch (err) {
      console.error("Erro ao verificar disponibilidade de veículos:", err)
      setError("Erro ao verificar disponibilidade de veículos. Tente novamente.")
    } finally {
      setIsLoadingVehicles(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      // Validações
      if (!pickupDate || !returnDate) {
        throw new Error("Selecione as datas de retirada e devolução")
      }

      if (!pickupTime || !returnTime) {
        throw new Error("Selecione os horários de retirada e devolução")
      }

      if (pickupDate > returnDate) {
        throw new Error("A data de devolução deve ser posterior à data de retirada")
      }

      if (!vehicleId) {
        throw new Error("Selecione um veículo")
      }

      if (!location) {
        throw new Error("Selecione um local")
      }

      if (!requesterName) {
        throw new Error("Informe o nome do reservista")
      }

      if (!costCenter) {
        throw new Error("Informe o centro de custo")
      }

      if (!reason) {
        throw new Error("Informe o motivo da reserva")
      }

      // Formatar as datas no formato correto para a API
      const formattedPickupDate = format(pickupDate, "yyyy-MM-dd")
      const formattedReturnDate = format(returnDate, "yyyy-MM-dd")

      const response = await fetch("/api/reservations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId,
          requesterName,
          costCenter,
          pickupDate: formattedPickupDate,
          returnDate: formattedReturnDate,
          pickupTime,
          returnTime,
          vehicleId: Number.parseInt(vehicleId),
          location,
          reason,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Erro ao criar reserva")
      }

      // Mostra mensagem de sucesso
      setSuccess(true)
      setReservationCode(data.reservationCode)

      // Atualiza a página após 3 segundos
      setTimeout(() => {
        router.refresh()
      }, 3000)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="bg-primary/20 text-primary border-primary">
          <CheckCircle2 className="h-4 w-4" />
          <AlertDescription>
            Reserva criada com sucesso! Seu código de reserva é: <strong>{reservationCode}</strong>
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="requesterName">Nome do Reservista *</Label>
          <Input
            id="requesterName"
            value={requesterName}
            onChange={(e) => setRequesterName(e.target.value)}
            required
            disabled={success}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="costCenter">Centro de Custo *</Label>
          <Input
            id="costCenter"
            value={costCenter}
            onChange={(e) => setCostCenter(e.target.value)}
            required
            disabled={success}
          />
        </div>

        <div className="space-y-2">
          <Label>Data de Retirada *</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn("w-full justify-start text-left font-normal", !pickupDate && "text-muted-foreground")}
                disabled={success}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {pickupDate ? format(pickupDate, "dd/MM/yyyy", { locale: ptBR }) : "Selecione uma data"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={pickupDate}
                onSelect={(date) => {
                  if (date) {
                    setPickupDate(date)
                    // Limpa o veículo selecionado quando a data muda
                    setVehicleId("")
                  }
                }}
                initialFocus
                disabled={(date) => {
                  // Permitir reservas a partir do dia atual
                  const today = new Date()
                  today.setHours(0, 0, 0, 0)
                  return date < today
                }}
                locale={ptBR}
                showOutsideDays={false}
              />
            </PopoverContent>
          </Popover>
        </div>

        <div className="space-y-2">
          <Label>Data de Devolução *</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn("w-full justify-start text-left font-normal", !returnDate && "text-muted-foreground")}
                disabled={success}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {returnDate ? format(returnDate, "dd/MM/yyyy", { locale: ptBR }) : "Selecione uma data"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={returnDate}
                onSelect={(date) => {
                  if (date) {
                    setReturnDate(date)
                    // Limpa o veículo selecionado quando a data muda
                    setVehicleId("")
                  }
                }}
                initialFocus
                disabled={(date) => {
                  // Permitir devolução no mesmo dia da retirada
                  if (pickupDate) {
                    // Se a data de retirada estiver definida, a data de devolução deve ser igual ou posterior
                    const pickupCopy = new Date(pickupDate)
                    pickupCopy.setHours(0, 0, 0, 0)
                    return date < pickupCopy
                  }

                  const today = new Date()
                  today.setHours(0, 0, 0, 0)
                  return date < today
                }}
                locale={ptBR}
                showOutsideDays={false}
              />
            </PopoverContent>
          </Popover>
        </div>

        <div className="space-y-2">
          <Label htmlFor="pickupTime">Horário de Retirada *</Label>
          <Input
            id="pickupTime"
            type="time"
            value={pickupTime}
            onChange={(e) => setPickupTime(e.target.value)}
            required
            disabled={success}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="returnTime">Horário de Devolução *</Label>
          <Input
            id="returnTime"
            type="time"
            value={returnTime}
            onChange={(e) => setReturnTime(e.target.value)}
            required
            disabled={success}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="location">Local *</Label>
          <Select
            value={location}
            onValueChange={(value) => {
              setLocation(value)
              setVehicleId("")
            }}
            disabled={success}
          >
            <SelectTrigger>
              <SelectValue placeholder="Selecione um local" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="MG1">MG1</SelectItem>
              <SelectItem value="MG2">MG2</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="vehicleId">Veículo *</Label>
          <Select
            value={vehicleId}
            onValueChange={setVehicleId}
            disabled={!location || !pickupDate || !returnDate || success || isLoadingVehicles}
          >
            <SelectTrigger>
              <SelectValue
                placeholder={
                  !location
                    ? "Selecione um local primeiro"
                    : !pickupDate || !returnDate
                      ? "Selecione as datas primeiro"
                      : isLoadingVehicles
                        ? "Carregando veículos..."
                        : availableVehicles.length === 0
                          ? "Nenhum veículo disponível para este período"
                          : "Selecione um veículo"
                }
              />
            </SelectTrigger>
            <SelectContent>
              {isLoadingVehicles ? (
                <SelectItem value="loading" disabled>
                  Carregando veículos...
                </SelectItem>
              ) : availableVehicles.length === 0 ? (
                <SelectItem value="no_vehicles" disabled>
                  Nenhum veículo disponível para este período
                </SelectItem>
              ) : (
                availableVehicles.map((vehicle) => (
                  <SelectItem key={vehicle.id} value={vehicle.id.toString()}>
                    {vehicle.model} - {vehicle.plate}
                  </SelectItem>
                ))
              )}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="reason">Motivo da Reserva *</Label>
        <Textarea
          id="reason"
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          required
          className="min-h-[100px]"
          disabled={success}
        />
      </div>

      <Button type="submit" className="w-full" disabled={loading || success}>
        {loading ? "Criando reserva..." : "Solicitar Reserva"}
      </Button>
    </form>
  )
}
