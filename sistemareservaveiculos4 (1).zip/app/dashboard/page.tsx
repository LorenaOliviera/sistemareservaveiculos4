import { requireAuth } from "@/lib/auth"
import { DashboardLayout } from "@/components/dashboard-layout"
import { ReservationForm } from "./reservation-form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { executeQuery } from "@/lib/db"

export default async function DashboardPage() {
  const user = await requireAuth()

  // Busca todos os veículos - a filtragem por disponibilidade será feita no cliente
  // com base na data selecionada pelo usuário
  const vehicles = await executeQuery(`
    SELECT * FROM vehicles 
    WHERE status = 'disponível' 
    ORDER BY model ASC
  `)

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Reserva de Veículos</h1>
          <p className="text-muted-foreground">Preencha o formulário abaixo para solicitar a reserva de um veículo</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Nova Reserva</CardTitle>
            <CardDescription>Todos os campos marcados com * são obrigatórios</CardDescription>
          </CardHeader>
          <CardContent>
            <ReservationForm vehicles={vehicles} userId={user.id} />
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
