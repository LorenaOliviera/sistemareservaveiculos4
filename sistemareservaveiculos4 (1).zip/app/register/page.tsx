import { Logo } from "@/components/logo"
import { RegisterForm } from "./register-form"
import { getCurrentUser } from "@/lib/auth"
import { redirect } from "next/navigation"

export default async function RegisterPage() {
  const user = await getCurrentUser()

  // Redireciona para o dashboard se o usuário já estiver logado
  if (user) {
    redirect("/dashboard")
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-secondary/30">
      <div className="w-full max-w-md p-8 space-y-8 bg-white rounded-lg shadow-lg">
        <div className="flex flex-col items-center space-y-2">
          <Logo />
          <h1 className="text-2xl font-bold text-center">Cadastro</h1>
          <p className="text-sm text-muted-foreground text-center">
            Crie sua conta para acessar o sistema de reserva de veículos
          </p>
        </div>

        <RegisterForm />
      </div>
    </div>
  )
}
