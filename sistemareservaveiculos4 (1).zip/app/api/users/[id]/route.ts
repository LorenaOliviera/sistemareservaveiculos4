import { type NextRequest, NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import { requireAdmin } from "@/lib/auth"

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const currentUser = await requireAdmin()

    const userId = Number.parseInt(params.id)

    if (isNaN(userId)) {
      return NextResponse.json({ error: "ID de usuário inválido" }, { status: 400 })
    }

    // Busca o usuário
    const users = await executeQuery("SELECT * FROM users WHERE id = $1", [userId])

    if (users.length === 0) {
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
    }

    // Obtém os dados da requisição
    const { name, role } = await request.json()

    // Validação básica
    if (!name || !role) {
      return NextResponse.json({ error: "Nome e tipo de usuário são obrigatórios" }, { status: 400 })
    }

    // Não permite que um usuário altere seu próprio papel
    if (userId === currentUser.id && role !== currentUser.role) {
      return NextResponse.json({ error: "Você não pode alterar seu próprio tipo de usuário" }, { status: 403 })
    }

    // Atualiza o usuário
    const result = await executeQuery(
      `
      UPDATE users 
      SET name = $1, role = $2, updated_at = NOW()
      WHERE id = $3
      RETURNING id, name, email, role, created_at, last_login, status
    `,
      [name, role, userId],
    )

    return NextResponse.json({
      success: true,
      user: result[0],
    })
  } catch (error: any) {
    console.error("Erro ao atualizar usuário:", error)
    return NextResponse.json({ error: error.message || "Erro ao atualizar usuário" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const currentUser = await requireAdmin()

    const userId = Number.parseInt(params.id)

    if (isNaN(userId)) {
      return NextResponse.json({ error: "ID de usuário inválido" }, { status: 400 })
    }

    // Verifica se o usuário existe
    const users = await executeQuery("SELECT * FROM users WHERE id = $1", [userId])

    if (users.length === 0) {
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
    }

    // Não permite excluir o próprio usuário
    if (userId === currentUser.id) {
      return NextResponse.json({ error: "Você não pode excluir seu próprio usuário" }, { status: 403 })
    }

    // Obter a data atual
    const today = new Date().toISOString().split("T")[0]

    // Verificar se a coluna rejection_reason existe
    const checkColumn = await executeQuery(`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'reservations' AND column_name = 'rejection_reason'
    `)

    // Cancelar todas as reservas futuras do usuário
    if (checkColumn.length > 0) {
      // Se a coluna existir, use-a
      await executeQuery(
        `
        UPDATE reservations 
        SET status = 'cancelada', 
            rejection_reason = 'Usuário removido do sistema', 
            updated_at = NOW() 
        WHERE user_id = $1 
        AND pickup_date >= $2
        AND status IN ('pendente', 'aprovada')
      `,
        [userId, today],
      )
    } else {
      // Se a coluna não existir, apenas atualize o status
      await executeQuery(
        `
        UPDATE reservations 
        SET status = 'cancelada', 
            updated_at = NOW() 
        WHERE user_id = $1 
        AND pickup_date >= $2
        AND status IN ('pendente', 'aprovada')
      `,
        [userId, today],
      )
    }

    // Exclui o usuário
    await executeQuery("DELETE FROM users WHERE id = $1", [userId])

    return NextResponse.json({
      success: true,
      message: "Usuário excluído com sucesso",
    })
  } catch (error: any) {
    console.error("Erro ao excluir usuário:", error)
    return NextResponse.json({ error: error.message || "Erro ao excluir usuário" }, { status: 500 })
  }
}
