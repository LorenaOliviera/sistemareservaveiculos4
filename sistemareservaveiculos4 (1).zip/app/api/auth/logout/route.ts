import { type NextRequest, NextResponse } from "next/server"
import { cookies } from "next/headers"
import { executeQuery } from "@/lib/db"

export async function POST(request: NextRequest) {
  try {
    const sessionId = cookies().get("session_id")?.value

    if (sessionId) {
      await executeQuery("DELETE FROM sessions WHERE id = $1", [sessionId])
      cookies().delete("session_id")
    }

    return NextResponse.json({ success: true, redirectUrl: "/login" })
  } catch (error) {
    console.error("Erro ao fazer logout:", error)
    return NextResponse.json({ success: false, error: "Erro ao fazer logout" }, { status: 500 })
  }
}

// Adicionar um manipulador GET para redirecionar para a página de login
// quando alguém tenta acessar esta rota diretamente
export async function GET(request: NextRequest) {
  return NextResponse.redirect(new URL("/login", request.url))
}
