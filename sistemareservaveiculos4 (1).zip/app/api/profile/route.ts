import { type NextRequest, NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"
import bcrypt from "bcryptjs"

export async function PUT(request: NextRequest) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const { name, currentPassword, newPassword } = await request.json()

    // Validação básica
    if (!name) {
      return NextResponse.json({ error: "Nome é obrigatório" }, { status: 400 })
    }

    // Se estiver alterando a senha, verifica a senha atual
    if (newPassword) {
      if (!currentPassword) {
        return NextResponse.json({ error: "Senha atual é obrigatória para alterar a senha" }, { status: 400 })
      }

      // Busca a senha atual do usuário
      const users = await executeQuery("SELECT password FROM users WHERE id = $1", [user.id])

      // Verifica se a senha atual está correta
      const passwordMatch = await bcrypt.compare(currentPassword, users[0].password)

      if (!passwordMatch) {
        return NextResponse.json({ error: "Senha atual incorreta" }, { status: 400 })
      }
    }

    // Prepara a query de atualização
    let query = "UPDATE users SET name = $1"
    const params: any[] = [name]

    // Se estiver alterando a senha, adiciona à query
    if (newPassword) {
      const hashedPassword = await bcrypt.hash(newPassword, 10)
      query += ", password = $2"
      params.push(hashedPassword)
    }

    // Adiciona a condição WHERE e RETURNING
    query += " WHERE id = $" + (params.length + 1)
    query += " RETURNING id, name, email, role, created_at, last_login, status"
    params.push(user.id)

    // Executa a query
    const result = await executeQuery(query, params)

    return NextResponse.json({
      success: true,
      user: result[0],
    })
  } catch (error: any) {
    console.error("Erro ao atualizar perfil:", error)
    return NextResponse.json({ error: error.message || "Erro ao atualizar perfil" }, { status: 500 })
  }
}
