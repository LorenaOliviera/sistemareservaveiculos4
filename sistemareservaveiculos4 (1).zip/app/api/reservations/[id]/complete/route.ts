import { type NextRequest, NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import { requireAdmin } from "@/lib/auth"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = await requireAdmin()

    const reservationId = Number.parseInt(params.id)

    if (isNaN(reservationId)) {
      return NextResponse.json({ error: "ID de reserva inválido" }, { status: 400 })
    }

    // Busca a reserva
    const reservations = await executeQuery("SELECT * FROM reservations WHERE id = $1", [reservationId])

    if (reservations.length === 0) {
      return NextResponse.json({ error: "Reserva não encontrada" }, { status: 404 })
    }

    const reservation = reservations[0]

    // Verifica se a reserva pode ser concluída (agora aceita reservas pendentes também)
    if (reservation.status !== "em_andamento" && reservation.status !== "pendente") {
      return NextResponse.json({ error: "Esta reserva não pode ser concluída" }, { status: 400 })
    }

    // Conclui a reserva
    await executeQuery("UPDATE reservations SET status = $1, updated_at = NOW() WHERE id = $2", [
      "concluida",
      reservationId,
    ])

    // Atualiza o status do veículo
    await executeQuery("UPDATE vehicles SET status = $1 WHERE id = $2", ["disponível", reservation.vehicle_id])

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("Erro ao concluir reserva:", error)
    return NextResponse.json({ error: error.message || "Erro ao concluir reserva" }, { status: 500 })
  }
}
