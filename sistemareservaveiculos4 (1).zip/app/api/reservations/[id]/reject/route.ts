import { type NextRequest, NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import { requireAdmin } from "@/lib/auth"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = await requireAdmin()

    const reservationId = Number.parseInt(params.id)

    if (isNaN(reservationId)) {
      return NextResponse.json({ error: "ID de reserva inválido" }, { status: 400 })
    }

    // Busca a reserva
    const reservations = await executeQuery("SELECT * FROM reservations WHERE id = $1", [reservationId])

    if (reservations.length === 0) {
      return NextResponse.json({ error: "Reserva não encontrada" }, { status: 404 })
    }

    const reservation = reservations[0]

    // Verifica se a reserva pode ser rejeitada
    if (reservation.status !== "pendente") {
      return NextResponse.json({ error: "Esta reserva não pode ser rejeitada" }, { status: 400 })
    }

    // Obtém a justificativa da requisição
    const body = await request.json()
    const justificativa = body.justificativa

    // Verifica se a justificativa foi fornecida
    if (!justificativa || justificativa.trim() === "") {
      return NextResponse.json(
        { error: "É necessário fornecer uma justificativa para rejeitar a reserva" },
        { status: 400 },
      )
    }

    // Rejeita a reserva e salva a justificativa
    await executeQuery("UPDATE reservations SET status = $1, rejection_reason = $2, updated_at = NOW() WHERE id = $3", [
      "cancelada",
      justificativa,
      reservationId,
    ])

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("Erro ao rejeitar reserva:", error)
    return NextResponse.json({ error: error.message || "Erro ao rejeitar reserva" }, { status: 500 })
  }
}
