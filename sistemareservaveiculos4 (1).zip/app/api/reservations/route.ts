import { type NextRequest, NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import { generateReservationCode } from "@/lib/utils"
import { getCurrentUser } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const {
      userId,
      requesterName,
      costCenter,
      pickupDate,
      returnDate,
      pickupTime,
      returnTime,
      vehicleId,
      location,
      reason,
    } = await request.json()

    // Validação básica
    if (
      !requesterName ||
      !costCenter ||
      !pickupDate ||
      !returnDate ||
      !pickupTime ||
      !returnTime ||
      !vehicleId ||
      !location ||
      !reason
    ) {
      return NextResponse.json({ error: "Todos os campos são obrigatórios" }, { status: 400 })
    }

    // Verifica se o veículo existe e está disponível
    const vehicles = await executeQuery("SELECT * FROM vehicles WHERE id = $1", [vehicleId])

    if (vehicles.length === 0) {
      return NextResponse.json({ error: "Veículo não encontrado" }, { status: 404 })
    }

    const vehicle = vehicles[0]

    if (vehicle.status !== "disponível") {
      return NextResponse.json({ error: "Veículo não está disponível" }, { status: 400 })
    }

    // Verifica se o veículo já está reservado para o período
    const overlappingReservations = await executeQuery(
      `
      SELECT * FROM reservations 
      WHERE vehicle_id = $1 
      AND status IN ('pendente', 'aprovada', 'em_andamento')
      AND (
        (pickup_date <= $2 AND return_date >= $2) OR
        (pickup_date <= $3 AND return_date >= $3) OR
        (pickup_date >= $2 AND return_date <= $3)
      )
    `,
      [vehicleId, pickupDate, returnDate],
    )

    if (overlappingReservations.length > 0) {
      return NextResponse.json({ error: "Veículo já reservado para este período" }, { status: 400 })
    }

    // Gera um código único para a reserva
    const reservationCode = generateReservationCode()

    // Cria a reserva
    const result = await executeQuery(
      `
      INSERT INTO reservations (
        reservation_code, user_id, vehicle_id, requester_name, 
        cost_center, pickup_date, return_date, pickup_time, 
        return_time, location, reason, status
      ) 
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      RETURNING *
    `,
      [
        reservationCode,
        userId,
        vehicleId,
        requesterName,
        costCenter,
        pickupDate,
        returnDate,
        pickupTime,
        returnTime,
        location,
        reason,
        "pendente",
      ],
    )

    return NextResponse.json({
      success: true,
      reservation: result[0],
      reservationCode,
    })
  } catch (error: any) {
    console.error("Erro ao criar reserva:", error)
    return NextResponse.json({ error: error.message || "Erro ao criar reserva" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status")
    const userId = searchParams.get("userId")

    let query = `
      SELECT r.*, v.model as vehicle_model, v.plate as vehicle_plate
      FROM reservations r
      JOIN vehicles v ON r.vehicle_id = v.id
    `

    const params: any[] = []
    const conditions: string[] = []

    // Filtra por status
    if (status) {
      // Dividir os status por vírgula para permitir múltiplos status
      const statusList = status.split(",")
      if (statusList.length > 0) {
        const statusConditions = statusList.map((_, index) => `r.status = $${params.length + index + 1}`)
        conditions.push(`(${statusConditions.join(" OR ")})`)
        params.push(...statusList)
      }
    }

    // Filtra por usuário (apenas para usuários normais)
    if (user.role !== "admin" || userId) {
      conditions.push(`r.user_id = $${params.length + 1}`)
      params.push(userId || user.id)
    }

    // Adiciona condições à query
    if (conditions.length > 0) {
      query += ` WHERE ${conditions.join(" AND ")}`
    }

    // Ordena por data de criação (mais recentes primeiro)
    query += " ORDER BY r.created_at DESC"

    const reservations = await executeQuery(query, params)

    return NextResponse.json(reservations)
  } catch (error: any) {
    console.error("Erro ao buscar reservas:", error)
    return NextResponse.json({ error: error.message || "Erro ao buscar reservas" }, { status: 500 })
  }
}
