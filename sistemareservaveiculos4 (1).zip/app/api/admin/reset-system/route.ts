import { type NextRequest, NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import { requireAdmin } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    // Verificar se o usuário é administrador
    const admin = await requireAdmin()

    // Remover todas as reservas
    await executeQuery("DELETE FROM reservations")

    // Redefinir o status de todos os veículos para "disponível"
    await executeQuery("UPDATE vehicles SET status = 'disponível'")

    return NextResponse.json({
      success: true,
      message: "Sistema resetado com sucesso. Todas as reservas foram removidas e os veículos estão disponíveis.",
    })
  } catch (error: any) {
    console.error("Erro ao resetar o sistema:", error)
    return NextResponse.json({ error: error.message || "Erro ao resetar o sistema" }, { status: 500 })
  }
}
