// Adicione o método DELETE à rota existente
import { type NextRequest, NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import { requireAdmin } from "@/lib/auth"

// Mantenha o método PUT existente...

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = await requireAdmin()

    const vehicleId = Number.parseInt(params.id)

    if (isNaN(vehicleId)) {
      return NextResponse.json({ error: "ID de veículo inválido" }, { status: 400 })
    }

    // Verifica se o veículo existe
    const vehicles = await executeQuery("SELECT * FROM vehicles WHERE id = $1", [vehicleId])

    if (vehicles.length === 0) {
      return NextResponse.json({ error: "Veículo não encontrado" }, { status: 404 })
    }

    // Verifica se o veículo tem reservas
    const reservations = await executeQuery(
      "SELECT * FROM reservations WHERE vehicle_id = $1 AND status IN ('pendente', 'aprovada', 'em_andamento')",
      [vehicleId],
    )

    if (reservations.length > 0) {
      return NextResponse.json(
        {
          error: "Este veículo possui reservas ativas. Cancele todas as reservas antes de excluir o veículo.",
        },
        { status: 400 },
      )
    }

    // Exclui o veículo
    await executeQuery("DELETE FROM vehicles WHERE id = $1", [vehicleId])

    return NextResponse.json({
      success: true,
      message: "Veículo excluído com sucesso",
    })
  } catch (error: any) {
    console.error("Erro ao excluir veículo:", error)
    return NextResponse.json({ error: error.message || "Erro ao excluir veículo" }, { status: 500 })
  }
}
