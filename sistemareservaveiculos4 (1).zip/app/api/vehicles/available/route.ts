import { type NextRequest, NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const location = searchParams.get("location")
    const pickupDate = searchParams.get("pickupDate")
    const returnDate = searchParams.get("returnDate")
    const excludeReservationId = searchParams.get("excludeReservationId")

    if (!location) {
      return NextResponse.json({ error: "Local é obrigatório" }, { status: 400 })
    }

    // Busca todos os veículos disponíveis no local especificado
    const allVehicles = await executeQuery(
      "SELECT * FROM vehicles WHERE location = $1 AND status = 'disponível' ORDER BY model ASC",
      [location],
    )

    // Se não houver datas selecionadas, retorna todos os veículos disponíveis
    if (!pickupDate || !returnDate) {
      return NextResponse.json(allVehicles)
    }

    // Busca IDs de veículos que já estão reservados no período
    // Modificado para verificar qualquer sobreposição de datas
    let query = `
      SELECT DISTINCT vehicle_id FROM reservations 
      WHERE status IN ('pendente', 'concluida')
      AND (
        (pickup_date <= $2 AND return_date >= $1) OR
        (pickup_date <= $3 AND return_date >= $2) OR
        (pickup_date >= $1 AND pickup_date <= $3) OR
        (return_date >= $1 AND return_date <= $3)
      )
    `

    const params = [pickupDate, pickupDate, returnDate]

    // Se estiver editando uma reserva, exclui a própria reserva da verificação
    if (excludeReservationId) {
      query += ` AND id != $4`
      params.push(excludeReservationId)
    }

    const reservedVehicles = await executeQuery(query, params)

    // Extrai os IDs dos veículos reservados
    const reservedIds = reservedVehicles.map((v) => v.vehicle_id)

    // Filtra os veículos que não estão na lista de reservados
    const availableVehicles = allVehicles.filter((vehicle) => !reservedIds.includes(vehicle.id))

    return NextResponse.json(availableVehicles)
  } catch (error: any) {
    console.error("Erro ao buscar veículos disponíveis:", error)
    return NextResponse.json({ error: error.message || "Erro ao buscar veículos disponíveis" }, { status: 500 })
  }
}
