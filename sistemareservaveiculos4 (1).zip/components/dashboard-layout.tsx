"use client"

import type { ReactNode } from "react"
import { useState } from "react"
import { Logo } from "./logo"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { useRouter } from "next/navigation"
import type { User } from "@/lib/auth"
import { LogOut, Car, Calendar, UserIcon, Settings, Users } from "lucide-react"

interface DashboardLayoutProps {
  user: User
  children: ReactNode
}

export function DashboardLayout({ user, children }: DashboardLayoutProps) {
  const router = useRouter()
  const [isLoggingOut, setIsLoggingOut] = useState(false)
  const isAdmin = user.role === "admin"

  const handleLogout = async () => {
    try {
      setIsLoggingOut(true)
      const response = await fetch("/api/auth/logout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      })

      const data = await response.json()

      if (data.success) {
        router.push("/login")
      } else {
        console.error("Erro ao fazer logout:", data.error)
      }
    } catch (error) {
      console.error("Erro ao fazer logout:", error)
    } finally {
      setIsLoggingOut(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-primary text-primary-foreground py-4 px-6 shadow-md">
        <div className="container mx-auto flex justify-between items-center">
          <Logo />

          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <span className="text-sm font-medium">{user.name}</span>
              <Button variant="ghost" size="icon" onClick={handleLogout} disabled={isLoggingOut} title="Sair">
                <LogOut className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex flex-1">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-border">
          <nav className="p-4 space-y-1">
            <Link href="/dashboard">
              <Button variant="ghost" className="w-full justify-start">
                <Calendar className="mr-2 h-5 w-5" />
                Reservas
              </Button>
            </Link>

            <Link href="/dashboard/history">
              <Button variant="ghost" className="w-full justify-start">
                <Calendar className="mr-2 h-5 w-5" />
                Histórico
              </Button>
            </Link>

            {isAdmin && (
              <>
                <div className="pt-2 pb-1">
                  <p className="text-xs font-medium text-muted-foreground px-4">Administração</p>
                </div>

                <Link href="/admin/dashboard">
                  <Button variant="ghost" className="w-full justify-start">
                    <Settings className="mr-2 h-5 w-5" />
                    Dashboard
                  </Button>
                </Link>

                <Link href="/admin/agenda">
                  <Button variant="ghost" className="w-full justify-start">
                    <Calendar className="mr-2 h-5 w-5" />
                    Agenda
                  </Button>
                </Link>

                <Link href="/admin/reservations">
                  <Button variant="ghost" className="w-full justify-start">
                    <Calendar className="mr-2 h-5 w-5" />
                    Reservas
                  </Button>
                </Link>

                <Link href="/admin/vehicles">
                  <Button variant="ghost" className="w-full justify-start">
                    <Car className="mr-2 h-5 w-5" />
                    Veículos
                  </Button>
                </Link>

                <Link href="/admin/users">
                  <Button variant="ghost" className="w-full justify-start">
                    <Users className="mr-2 h-5 w-5" />
                    Usuários
                  </Button>
                </Link>

                <Link href="/admin/settings">
                  <Button variant="ghost" className="w-full justify-start">
                    <Settings className="mr-2 h-5 w-5" />
                    Configurações
                  </Button>
                </Link>
              </>
            )}

            <Link href="/profile">
              <Button variant="ghost" className="w-full justify-start">
                <UserIcon className="mr-2 h-5 w-5" />
                Meu Perfil
              </Button>
            </Link>
          </nav>
        </aside>

        {/* Main content */}
        <main className="flex-1 bg-secondary/10 p-6">{children}</main>
      </div>
    </div>
  )
}
