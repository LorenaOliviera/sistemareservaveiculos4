import Link from "next/link"
import Image from "next/image"

export function Logo() {
  return (
    <Link href="/" className="flex items-center space-x-2">
      <div className="relative h-12 w-48">
        <Image
          src="/images/ld-celulose-logo-white.png"
          alt="LD Celulose"
          fill
          style={{ objectFit: "contain" }}
          priority
        />
      </div>
    </Link>
  )
}
