"use client"

import { useState, useEffect } from "react"

export function CurrentTime() {
  const [dateTime, setDateTime] = useState<string>("")

  useEffect(() => {
    // Função para atualizar a data e hora
    const updateDateTime = () => {
      const now = new Date()
      const formattedDate = now.toLocaleDateString("pt-BR")
      const formattedTime = now.toLocaleTimeString("pt-BR")
      setDateTime(`${formattedDate} às ${formattedTime}`)
    }

    // Atualiza imediatamente
    updateDateTime()

    // Atualiza a cada segundo
    const interval = setInterval(updateDateTime, 1000)

    // Limpa o intervalo quando o componente é desmontado
    return () => clearInterval(interval)
  }, [])

  return <div className="text-sm text-muted-foreground">📅 {dateTime}</div>
}
