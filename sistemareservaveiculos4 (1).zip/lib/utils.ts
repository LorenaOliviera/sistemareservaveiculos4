import { format } from "date-fns"

export function formatDate(date: string | Date): string {
  try {
    if (typeof date === "string") {
      return format(new Date(date), "dd/MM/yyyy")
    } else {
      return format(date, "dd/MM/yyyy")
    }
  } catch (error) {
    console.error("Erro ao formatar data:", error)
    return "Data inválida"
  }
}

export function formatTime(time: string): string {
  try {
    const [hours, minutes] = time.split(":")
    return `${hours}:${minutes}`
  } catch (error) {
    console.error("Erro ao formatar hora:", error)
    return "Hora inválida"
  }
}

export function generateReservationCode(): string {
  const prefix = "RES"
  const randomNumber = Math.floor(100000 + Math.random() * 900000) // Número aleatório de 6 dígitos
  return `${prefix}-${randomNumber}`
}

type ClassValue = string | number | boolean | undefined | null

export function cn(...inputs: ClassValue[]): string {
  return inputs.filter(Boolean).join(" ")
}
