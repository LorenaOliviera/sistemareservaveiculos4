import { neon, neonConfig } from "@neondatabase/serverless"
import { Pool } from "@neondatabase/serverless"

// Configurar o Neon para usar WebSockets
neonConfig.webSocketConstructor = globalThis.WebSocket
neonConfig.fetchConnectionCache = true

// Declarar variáveis no escopo do módulo
let sql: any
let pool: Pool

// Função para tentar formatar a string de conexão
function formatConnectionString(str: string): string {
  // Se já estiver no formato correto, retorna
  if (str.startsWith("postgresql://")) {
    return str
  }

  // Tenta formatar strings no formato user:password@host/dbname
  if (str.includes("@") && str.includes("/")) {
    return `postgresql://${str}`
  }

  // Tenta formatar strings no formato postgres://user:password@host/dbname
  if (str.startsWith("postgres://")) {
    return str.replace("postgres://", "postgresql://")
  }

  // Se for uma string no formato antigo do Neon (sem postgresql://)
  if (str.includes("@") && str.includes(".")) {
    const parts = str.split("@")
    if (parts.length === 2) {
      const credentials = parts[0]
      const hostDb = parts[1]
      return `postgresql://${credentials}@${hostDb}`
    }
  }

  throw new Error(
    "String de conexão do banco de dados inválida. Formato esperado: postgresql://user:password@host.tld/dbname",
  )
}

// Função para executar queries SQL
export async function executeQuery(query: string, params: any[] = []) {
  if (!pool) {
    throw new Error("Conexão com o banco de dados não configurada corretamente")
  }

  try {
    // Usar o pool para consultas parametrizadas
    const result = await pool.query(query, params)
    return result.rows
  } catch (error) {
    console.error("Erro ao executar query:", error)
    throw error
  }
}

// Inicializar a conexão
try {
  // Obter a string de conexão
  let connectionString = process.env.DATABASE_URL || ""

  // Tenta formatar a string de conexão
  connectionString = formatConnectionString(connectionString)

  console.log("Conectando ao banco de dados com:", connectionString.replace(/\/\/([^:]+):([^@]+)@/, "//***:***@"))

  // Criar o cliente SQL e o pool
  sql = neon(connectionString)
  pool = new Pool({ connectionString })
} catch (error) {
  console.error("Erro ao configurar conexão com o banco de dados:", error)
  // Não rethrow aqui para permitir que a aplicação continue carregando
  // O erro será lançado quando executeQuery for chamado
}

// Exporta o cliente sql para acesso direto se necessário
export const db = { sql, pool }
