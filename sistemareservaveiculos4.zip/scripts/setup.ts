import { execSync } from "child_process"
import fs from "fs"
import path from "path"
import readline from "readline"

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
})

async function question(query: string): Promise<string> {
  return new Promise((resolve) => {
    rl.question(query, (answer) => {
      resolve(answer)
    })
  })
}

async function setupProject() {
  console.log("\n🚀 Iniciando configuração do projeto Sistema de Reserva de Veículos\n")

  try {
    // Verificar se o arquivo .env existe
    const envPath = path.join(process.cwd(), ".env")
    if (!fs.existsSync(envPath)) {
      console.log("⚠️ Arquivo .env não encontrado. Criando...")

      console.log("\n📝 A URL do banco de dados deve estar no formato:")
      console.log("   postgresql://user:password@host.tld/dbname")
      console.log("   Exemplo: postgresql://myuser:mypassword@ep-cool-snow-123456.us-east-2.aws.neon.tech/neondb")

      const databaseUrl =
        process.env.DATABASE_URL || (await question("\nDigite a URL do banco de dados Neon (DATABASE_URL): "))

      fs.writeFileSync(envPath, `DATABASE_URL="${databaseUrl}"\n`)
      console.log("✅ Arquivo .env criado com sucesso!")
    } else {
      console.log("✅ Arquivo .env já existe.")
    }

    // Instalar dependências
    console.log("\n📦 Verificando dependências...")
    try {
      execSync("npm list", { stdio: "ignore" })
      console.log("✅ Dependências já instaladas.")
    } catch (error) {
      console.log("⚠️ Instalando dependências...")
      execSync("npm install", { stdio: "inherit" })
      console.log("✅ Dependências instaladas com sucesso!")
    }

    // Inicializar o banco de dados
    console.log("\n🗄️ Inicializando o banco de dados...")
    try {
      execSync("npx tsx scripts/init-db.ts", { stdio: "inherit" })
      console.log("✅ Banco de dados inicializado com sucesso!")
    } catch (error) {
      console.error("❌ Erro ao inicializar o banco de dados:", error)
      console.log("\n⚠️ Verifique se a URL do banco de dados está correta no arquivo .env")
      console.log("   O formato deve ser: postgresql://user:password@host.tld/dbname")
      throw error
    }

    // Iniciar o servidor de desenvolvimento
    const startDev = await question("\n🔄 Deseja iniciar o servidor de desenvolvimento? (s/n): ")
    if (startDev.toLowerCase() === "s") {
      console.log("\n🚀 Iniciando servidor de desenvolvimento...")
      console.log("📝 Acesse http://localhost:3000 no seu navegador")
      console.log("📝 Credenciais de teste:")
      console.log("   - Admin: admin@lenzing.com / admin123")
      console.log("   - Solicitante: solicitante@lenzing.com / admin123")

      execSync("npm run dev", { stdio: "inherit" })
    } else {
      // Instruções para deploy
      console.log("\n🚀 Para iniciar o servidor de desenvolvimento mais tarde, execute:")
      console.log("   npm run dev")

      console.log("\n🌐 Para fazer deploy no Vercel:")
      console.log("1. Instale a CLI do Vercel: npm i -g vercel")
      console.log("2. Execute: vercel")
      console.log("3. Siga as instruções na tela")
      console.log("4. Não esqueça de configurar a variável de ambiente DATABASE_URL no Vercel")
    }
  } catch (error) {
    console.error("\n❌ Erro durante a configuração:", error)
  } finally {
    rl.close()
  }
}

setupProject()
