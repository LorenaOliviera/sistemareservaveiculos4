import { type NextRequest, NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const reservationId = Number.parseInt(params.id)

    if (isNaN(reservationId)) {
      return NextResponse.json({ error: "ID de reserva inválido" }, { status: 400 })
    }

    // Busca a reserva
    const reservations = await executeQuery("SELECT * FROM reservations WHERE id = $1", [reservationId])

    if (reservations.length === 0) {
      return NextResponse.json({ error: "Reserva não encontrada" }, { status: 404 })
    }

    const reservation = reservations[0]

    // Verifica se o usuário é o dono da reserva ou um administrador
    if (reservation.user_id !== user.id && user.role !== "admin") {
      return NextResponse.json({ error: "Não autorizado a editar esta reserva" }, { status: 403 })
    }

    // Obtém os dados da requisição
    const { requesterName, costCenter, pickupDate, returnDate, pickupTime, returnTime, vehicleId, location, reason } =
      await request.json()

    // Validação básica
    if (
      !requesterName ||
      !costCenter ||
      !pickupDate ||
      !returnDate ||
      !pickupTime ||
      !returnTime ||
      !vehicleId ||
      !location ||
      !reason
    ) {
      return NextResponse.json({ error: "Todos os campos são obrigatórios" }, { status: 400 })
    }

    // Verifica se o veículo existe
    const vehicles = await executeQuery("SELECT * FROM vehicles WHERE id = $1", [vehicleId])

    if (vehicles.length === 0) {
      return NextResponse.json({ error: "Veículo não encontrado" }, { status: 404 })
    }

    // Verifica se o veículo já está reservado para o período (excluindo a própria reserva)
    const overlappingReservations = await executeQuery(
      `
      SELECT * FROM reservations 
      WHERE vehicle_id = $1 
      AND id != $2
      AND status IN ('pendente', 'aprovada', 'em_andamento')
      AND (
        (pickup_date <= $3 AND return_date >= $3) OR
        (pickup_date <= $4 AND return_date >= $4) OR
        (pickup_date >= $3 AND pickup_date <= $4)
      )
    `,
      [vehicleId, reservationId, pickupDate, returnDate],
    )

    if (overlappingReservations.length > 0) {
      return NextResponse.json({ error: "Veículo já reservado para este período" }, { status: 400 })
    }

    // Atualiza a reserva
    const result = await executeQuery(
      `
      UPDATE reservations 
      SET requester_name = $1, cost_center = $2, pickup_date = $3, return_date = $4, 
          pickup_time = $5, return_time = $6, vehicle_id = $7, location = $8, reason = $9, updated_at = NOW()
      WHERE id = $10
      RETURNING *
    `,
      [
        requesterName,
        costCenter,
        pickupDate,
        returnDate,
        pickupTime,
        returnTime,
        vehicleId,
        location,
        reason,
        reservationId,
      ],
    )

    // Busca informações do veículo para retornar
    const vehicleInfo = await executeQuery("SELECT model, plate FROM vehicles WHERE id = $1", [vehicleId])

    // Combina os dados da reserva com as informações do veículo
    const updatedReservation = {
      ...result[0],
      vehicle_model: vehicleInfo[0].model,
      vehicle_plate: vehicleInfo[0].plate,
    }

    return NextResponse.json({
      success: true,
      reservation: updatedReservation,
    })
  } catch (error: any) {
    console.error("Erro ao atualizar reserva:", error)
    return NextResponse.json({ error: error.message || "Erro ao atualizar reserva" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    // Verificar se o usuário é administrador
    if (user.role !== "admin") {
      return NextResponse.json({ error: "Apenas administradores podem excluir reservas" }, { status: 403 })
    }

    const reservationId = Number.parseInt(params.id)

    if (isNaN(reservationId)) {
      return NextResponse.json({ error: "ID de reserva inválido" }, { status: 400 })
    }

    // Busca a reserva
    const reservations = await executeQuery("SELECT * FROM reservations WHERE id = $1", [reservationId])

    if (reservations.length === 0) {
      return NextResponse.json({ error: "Reserva não encontrada" }, { status: 404 })
    }

    const reservation = reservations[0]

    // Verifica se a reserva pode ser excluída (apenas concluídas ou canceladas)
    if (reservation.status !== "concluida" && reservation.status !== "cancelada") {
      return NextResponse.json(
        {
          error: "Apenas reservas concluídas ou canceladas podem ser excluídas",
        },
        { status: 400 },
      )
    }

    // Exclui a reserva
    await executeQuery("DELETE FROM reservations WHERE id = $1", [reservationId])

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("Erro ao excluir reserva:", error)
    return NextResponse.json({ error: error.message || "Erro ao excluir reserva" }, { status: 500 })
  }
}
