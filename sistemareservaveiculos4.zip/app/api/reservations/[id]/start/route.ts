import { type NextRequest, NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import { requireAdmin } from "@/lib/auth"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = await requireAdmin()

    const reservationId = Number.parseInt(params.id)

    if (isNaN(reservationId)) {
      return NextResponse.json({ error: "ID de reserva inválido" }, { status: 400 })
    }

    // Busca a reserva
    const reservations = await executeQuery("SELECT * FROM reservations WHERE id = $1", [reservationId])

    if (reservations.length === 0) {
      return NextResponse.json({ error: "Reserva não encontrada" }, { status: 404 })
    }

    const reservation = reservations[0]

    // Verifica se a reserva pode ser iniciada
    if (reservation.status !== "pendente" && reservation.status !== "aprovada") {
      return NextResponse.json({ error: "Esta reserva não pode ser iniciada" }, { status: 400 })
    }

    // Inicia a reserva
    await executeQuery("UPDATE reservations SET status = $1, updated_at = NOW() WHERE id = $2", [
      "em_andamento",
      reservationId,
    ])

    // Atualiza o status do veículo
    await executeQuery("UPDATE vehicles SET status = $1 WHERE id = $2", ["em_uso", reservation.vehicle_id])

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("Erro ao iniciar reserva:", error)
    return NextResponse.json({ error: error.message || "Erro ao iniciar reserva" }, { status: 500 })
  }
}
