import { type NextRequest, NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const reservationId = Number.parseInt(params.id)

    if (isNaN(reservationId)) {
      return NextResponse.json({ error: "ID de reserva inválido" }, { status: 400 })
    }

    // Busca a reserva
    const reservations = await executeQuery("SELECT * FROM reservations WHERE id = $1", [reservationId])

    if (reservations.length === 0) {
      return NextResponse.json({ error: "Reserva não encontrada" }, { status: 404 })
    }

    const reservation = reservations[0]

    // Verifica se o usuário é o dono da reserva ou um administrador
    if (reservation.user_id !== user.id && user.role !== "admin") {
      return NextResponse.json({ error: "Não autorizado a cancelar esta reserva" }, { status: 403 })
    }

    // Verifica se a reserva pode ser cancelada
    if (reservation.status !== "pendente" && reservation.status !== "aprovada") {
      return NextResponse.json({ error: "Esta reserva não pode ser cancelada" }, { status: 400 })
    }

    // Cancela a reserva
    await executeQuery("UPDATE reservations SET status = $1, updated_at = NOW() WHERE id = $2", [
      "cancelada",
      reservationId,
    ])

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("Erro ao cancelar reserva:", error)
    return NextResponse.json({ error: error.message || "Erro ao cancelar reserva" }, { status: 500 })
  }
}
