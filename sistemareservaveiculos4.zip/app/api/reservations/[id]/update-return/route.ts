import { type NextRequest, NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import { requireAdmin } from "@/lib/auth"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = await requireAdmin()

    const reservationId = Number.parseInt(params.id)

    if (isNaN(reservationId)) {
      return NextResponse.json({ error: "ID de reserva inválido" }, { status: 400 })
    }

    // Busca a reserva
    const reservations = await executeQuery("SELECT * FROM reservations WHERE id = $1", [reservationId])

    if (reservations.length === 0) {
      return NextResponse.json({ error: "Reserva não encontrada" }, { status: 404 })
    }

    const reservation = reservations[0]

    // Verifica se a reserva está em andamento
    if (reservation.status !== "em_andamento") {
      return NextResponse.json(
        { error: "Apenas reservas em andamento podem ter a data de devolução atualizada" },
        { status: 400 },
      )
    }

    // Obtém os dados da requisição
    const { returnDate, returnTime } = await request.json()

    // Validação básica
    if (!returnDate || !returnTime) {
      return NextResponse.json({ error: "Data e horário de devolução são obrigatórios" }, { status: 400 })
    }

    // Verifica se a nova data de devolução é posterior à data de retirada
    if (returnDate < reservation.pickup_date) {
      return NextResponse.json({ error: "A data de devolução deve ser posterior à data de retirada" }, { status: 400 })
    }

    // Atualiza a data de devolução
    const result = await executeQuery(
      `
      UPDATE reservations 
      SET return_date = $1, return_time = $2, updated_at = NOW()
      WHERE id = $3
      RETURNING *
    `,
      [returnDate, returnTime, reservationId],
    )

    return NextResponse.json({
      success: true,
      reservation: result[0],
    })
  } catch (error: any) {
    console.error("Erro ao atualizar data de devolução:", error)
    return NextResponse.json({ error: error.message || "Erro ao atualizar data de devolução" }, { status: 500 })
  }
}
