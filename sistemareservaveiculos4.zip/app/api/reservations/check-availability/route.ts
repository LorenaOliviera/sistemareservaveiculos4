import { type NextRequest, NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const location = searchParams.get("location")
    const pickupDate = searchParams.get("pickupDate")
    const returnDate = searchParams.get("returnDate")
    const excludeReservationId = searchParams.get("excludeReservationId")

    if (!location || !pickupDate || !returnDate) {
      return NextResponse.json({ error: "Parâmetros incompletos" }, { status: 400 })
    }

    console.log("Verificando disponibilidade:", {
      location,
      pickupDate,
      returnDate,
      excludeReservationId,
    })

    // Busca reservas que se sobrepõem ao período solicitado
    // Incluindo todos os status relevantes: pendente, aprovada, em_andamento
    let query = `
      SELECT r.* FROM reservations r
      JOIN vehicles v ON r.vehicle_id = v.id
      WHERE v.location = $1
      AND r.status IN ('pendente', 'aprovada', 'em_andamento')
      AND (
        (r.pickup_date <= $2 AND r.return_date >= $2) OR
        (r.pickup_date <= $3 AND r.return_date >= $3) OR
        (r.pickup_date >= $2 AND r.pickup_date <= $3)
      )
    `

    const params = [location, pickupDate, returnDate]

    // Se estiver editando uma reserva, exclui a própria reserva da verificação
    if (excludeReservationId) {
      query += ` AND r.id != $4`
      params.push(excludeReservationId)
    }

    const overlappingReservations = await executeQuery(query, params)

    console.log(`Encontradas ${overlappingReservations.length} reservas sobrepostas para o período`)

    return NextResponse.json(overlappingReservations)
  } catch (error: any) {
    console.error("Erro ao verificar disponibilidade:", error)
    return NextResponse.json({ error: error.message || "Erro ao verificar disponibilidade" }, { status: 500 })
  }
}
