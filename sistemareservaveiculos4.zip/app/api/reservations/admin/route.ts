import { type NextRequest, NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import { generateReservationCode } from "@/lib/utils"
import { requireAdmin } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    const admin = await requireAdmin()

    const {
      requesterName,
      costCenter,
      pickupDate,
      returnDate,
      pickupTime,
      returnTime,
      vehicleId,
      location,
      reason,
      status = "aprovada", // Reservas criadas pelo admin já são aprovadas
    } = await request.json()

    // Validação básica
    if (
      !requesterName ||
      !costCenter ||
      !pickupDate ||
      !returnDate ||
      !pickupTime ||
      !returnTime ||
      !vehicleId ||
      !location ||
      !reason
    ) {
      return NextResponse.json({ error: "Todos os campos são obrigatórios" }, { status: 400 })
    }

    // Verifica se o veículo existe e está disponível
    const vehicles = await executeQuery("SELECT * FROM vehicles WHERE id = $1", [vehicleId])

    if (vehicles.length === 0) {
      return NextResponse.json({ error: "Veículo não encontrado" }, { status: 404 })
    }

    const vehicle = vehicles[0]

    if (vehicle.status !== "disponível") {
      return NextResponse.json({ error: "Veículo não está disponível" }, { status: 400 })
    }

    // Verifica se o veículo já está reservado para o período
    const overlappingReservations = await executeQuery(
      `
      SELECT * FROM reservations 
      WHERE vehicle_id = $1 
      AND status IN ('pendente', 'aprovada', 'em_andamento')
      AND (
        (pickup_date <= $2 AND return_date >= $2) OR
        (pickup_date <= $3 AND return_date >= $3) OR
        (pickup_date >= $2 AND return_date <= $3)
      )
    `,
      [vehicleId, pickupDate, returnDate],
    )

    if (overlappingReservations.length > 0) {
      return NextResponse.json({ error: "Veículo já reservado para este período" }, { status: 400 })
    }

    // Gera um código único para a reserva
    const reservationCode = generateReservationCode()

    // Cria a reserva
    const result = await executeQuery(
      `
      INSERT INTO reservations (
        reservation_code, user_id, vehicle_id, requester_name, 
        cost_center, pickup_date, return_date, pickup_time, 
        return_time, location, reason, status
      ) 
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      RETURNING *
    `,
      [
        reservationCode,
        admin.id, // O admin é o usuário que está criando a reserva
        vehicleId,
        requesterName,
        costCenter,
        pickupDate,
        returnDate,
        pickupTime,
        returnTime,
        location,
        reason,
        status,
      ],
    )

    // Se a reserva for aprovada e começar hoje, atualiza o status do veículo para "em_uso"
    if (status === "aprovada" || status === "em_andamento") {
      const today = new Date().toISOString().split("T")[0]
      if (pickupDate <= today && returnDate >= today) {
        await executeQuery("UPDATE vehicles SET status = $1 WHERE id = $2", ["em_uso", vehicleId])
      }
    }

    return NextResponse.json({
      success: true,
      reservation: result[0],
      reservationCode,
    })
  } catch (error: any) {
    console.error("Erro ao criar reserva:", error)
    return NextResponse.json({ error: error.message || "Erro ao criar reserva" }, { status: 500 })
  }
}
