import { type NextRequest, NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import bcrypt from "bcryptjs"

export async function GET(request: NextRequest) {
  try {
    // Gerar hash da senha
    const password = "Fran9915300193030"
    const hashedPassword = await bcrypt.hash(password, 10)

    // Atualizar a senha do usuário
    await executeQuery("UPDATE users SET password = $1 WHERE email = $2", [hashedPassword, "l.oliviera@lenzing.com"])

    return NextResponse.json({
      success: true,
      message: "Senha atualizada com sucesso",
      hashedPassword,
    })
  } catch (error: any) {
    console.error("Erro ao atualizar senha:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
