import { type NextRequest, NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import { requireAdmin } from "@/lib/auth"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const currentUser = await requireAdmin()

    const userId = Number.parseInt(params.id)

    if (isNaN(userId)) {
      return NextResponse.json({ error: "ID de usuário inválido" }, { status: 400 })
    }

    // Verifica se o usuário existe
    const users = await executeQuery("SELECT * FROM users WHERE id = $1", [userId])

    if (users.length === 0) {
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 })
    }

    const user = users[0]

    // Não permite desativar o próprio usuário
    if (userId === currentUser.id) {
      return NextResponse.json({ error: "Você não pode desativar seu próprio usuário" }, { status: 403 })
    }

    // Alterna o status do usuário
    const result = await executeQuery(
      `
      UPDATE users SET
        status = NOT status
      WHERE id = $1
      RETURNING id, name, email, role, created_at, last_login, status
    `,
      [userId],
    )

    return NextResponse.json({
      success: true,
      user: result[0],
    })
  } catch (error: any) {
    console.error("Erro ao alterar status do usuário:", error)
    return NextResponse.json({ error: error.message || "Erro ao alterar status do usuário" }, { status: 500 })
  }
}
