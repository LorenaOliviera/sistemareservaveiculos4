import { type NextRequest, NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import { requireAdmin } from "@/lib/auth"
import bcrypt from "bcryptjs"

export async function POST(request: NextRequest) {
  try {
    const user = await requireAdmin()

    const { name, email, password, role } = await request.json()

    // Validação básica
    if (!name || !email || !password) {
      return NextResponse.json({ error: "Nome, email e senha são obrigatórios" }, { status: 400 })
    }

    // Validação do email
    if (!email.endsWith("@lenzing.com")) {
      return NextResponse.json({ error: "Apenas emails do domínio @lenzing.com são permitidos" }, { status: 400 })
    }

    // Verifica se já existe um usuário com o mesmo email
    const existingUsers = await executeQuery("SELECT * FROM users WHERE email = $1", [email])

    if (existingUsers.length > 0) {
      return NextResponse.json({ error: "Já existe um usuário com este email" }, { status: 400 })
    }

    // Hash da senha
    const hashedPassword = await bcrypt.hash(password, 10)

    // Cria o usuário
    const result = await executeQuery(
      `
      INSERT INTO users (name, email, password, role, status)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING id, name, email, role, created_at, status
    `,
      [name, email, hashedPassword, role, true],
    )

    return NextResponse.json({
      success: true,
      user: result[0],
    })
  } catch (error: any) {
    console.error("Erro ao criar usuário:", error)
    return NextResponse.json({ error: error.message || "Erro ao criar usuário" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const user = await requireAdmin()

    const { searchParams } = new URL(request.url)
    const role = searchParams.get("role")
    const status = searchParams.get("status")

    let query = `
      SELECT id, name, email, role, created_at, last_login, status
      FROM users
    `

    const params: any[] = []
    const conditions: string[] = []

    // Filtra por role
    if (role) {
      conditions.push(`role = $${params.length + 1}`)
      params.push(role)
    }

    // Filtra por status
    if (status) {
      conditions.push(`status = $${params.length + 1}`)
      params.push(status === "true")
    }

    // Adiciona condições à query
    if (conditions.length > 0) {
      query += ` WHERE ${conditions.join(" AND ")}`
    }

    // Ordena por nome
    query += " ORDER BY name ASC"

    const users = await executeQuery(query, params)

    return NextResponse.json(users)
  } catch (error: any) {
    console.error("Erro ao buscar usuários:", error)
    return NextResponse.json({ error: error.message || "Erro ao buscar usuários" }, { status: 500 })
  }
}
