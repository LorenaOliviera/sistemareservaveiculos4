import { type NextRequest, NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import { requireAdmin } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    const user = await requireAdmin()

    const { plate, model, year, color, capacity, status, location, maintenance_date } = await request.json()

    // Validação básica
    if (!plate || !model || !location) {
      return NextResponse.json({ error: "Placa, modelo e local são obrigatórios" }, { status: 400 })
    }

    // Verifica se já existe um veículo com a mesma placa
    const existingVehicles = await executeQuery("SELECT * FROM vehicles WHERE plate = $1", [plate])

    if (existingVehicles.length > 0) {
      return NextResponse.json({ error: "Já existe um veículo com esta placa" }, { status: 400 })
    }

    // Cria o veículo
    const result = await executeQuery(
      `
      INSERT INTO vehicles (
        plate, model, year, color, capacity, status, location, maintenance_date
      ) 
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *
    `,
      [plate, model, year, color, capacity, status, location, maintenance_date],
    )

    return NextResponse.json({
      success: true,
      vehicle: result[0],
    })
  } catch (error: any) {
    console.error("Erro ao criar veículo:", error)
    return NextResponse.json({ error: error.message || "Erro ao criar veículo" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const user = await requireAdmin()

    const { searchParams } = new URL(request.url)
    const location = searchParams.get("location")
    const status = searchParams.get("status")

    let query = "SELECT * FROM vehicles"
    const params: any[] = []
    const conditions: string[] = []

    // Filtra por localização
    if (location) {
      conditions.push(`location = $${params.length + 1}`)
      params.push(location)
    }

    // Filtra por status
    if (status) {
      conditions.push(`status = $${params.length + 1}`)
      params.push(status)
    }

    // Adiciona condições à query
    if (conditions.length > 0) {
      query += ` WHERE ${conditions.join(" AND ")}`
    }

    // Ordena por modelo
    query += " ORDER BY model ASC"

    const vehicles = await executeQuery(query, params)

    return NextResponse.json(vehicles)
  } catch (error: any) {
    console.error("Erro ao buscar veículos:", error)
    return NextResponse.json({ error: error.message || "Erro ao buscar veículos" }, { status: 500 })
  }
}
