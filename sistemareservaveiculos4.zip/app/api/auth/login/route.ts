import { type NextRequest, NextResponse } from "next/server"
import { loginUser } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    const { email, password, expectedRole } = await request.json()

    // Validação básica
    if (!email || !password) {
      return NextResponse.json({ error: "Email e senha são obrigatórios" }, { status: 400 })
    }

    // Tenta fazer login
    const user = await loginUser(email, password)

    // Verifica se o papel do usuário corresponde ao esperado
    if (expectedRole === "admin" && user.role !== "admin") {
      return NextResponse.json(
        { error: "Você não tem permissão para acessar a área de administrador" },
        { status: 403 },
      )
    }

    // Retorna o papel do usuário para redirecionamento adequado
    return NextResponse.json({
      success: true,
      role: user.role,
    })
  } catch (error: any) {
    console.error("Erro na rota de login:", error)
    return NextResponse.json({ error: error.message }, { status: 401 })
  }
}
