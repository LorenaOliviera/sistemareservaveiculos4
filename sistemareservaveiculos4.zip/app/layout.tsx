import type React from "react"
import type { Metadata } from "next"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"

export const metadata: Metadata = {
  title: "Reservas de Veículos - LD Celulose",
  description: "Sistema de reserva de veículos corporativos da LD Celulose",
  generator: "v0.dev",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <head>
        <style>{`
          body {
            font-family: Arial, sans-serif !important;
          }
        `}</style>
      </head>
      <body style={{ fontFamily: "Arial, sans-serif" }}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false} disableTransitionOnChange>
          {children}
        </ThemeProvider>
        <footer className="text-center text-sm text-muted-foreground py-4 border-t mt-auto">
          © 2025 Lorena Oliveira - Todos os direitos reservados.
        </footer>
      </body>
    </html>
  )
}

import "./globals.css"

import "./globals.css"


import './globals.css'