"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { formatDate } from "@/lib/utils"
import { Car, Users, Calendar } from "lucide-react"

interface AdminDashboardContentProps {
  location: string
  reservationStats: {
    pending_count: number
    approved_count: number
    ongoing_count: number
    completed_count: number
    canceled_count: number
    total_count: number
  }
  vehicleStats: {
    available_count: number
    in_use_count: number
    maintenance_count: number
    total_count: number
  }
  userStats: {
    admin_count: number
    requester_count: number
    active_count: number
    inactive_count: number
    total_count: number
  }
  recentReservations: any[]
}

export function AdminDashboardContent({
  location,
  reservationStats,
  vehicleStats,
  userStats,
  recentReservations,
}: AdminDashboardContentProps) {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pendente":
        return (
          <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">
            Pendente
          </Badge>
        )
      case "aprovada":
        return (
          <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">
            Aprovada
          </Badge>
        )
      case "em_andamento":
        return (
          <Badge variant="outline" className="bg-primary/20 text-primary border-primary">
            Em Andamento
          </Badge>
        )
      case "concluida":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
            Concluída
          </Badge>
        )
      case "cancelada":
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">
            Cancelada
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="space-y-6 mt-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Reservas Totais</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{reservationStats.total_count}</div>
            <p className="text-xs text-muted-foreground">
              {reservationStats.pending_count} pendentes, {reservationStats.ongoing_count} em andamento
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Veículos</CardTitle>
            <Car className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{vehicleStats.total_count}</div>
            <p className="text-xs text-muted-foreground">
              {vehicleStats.available_count} disponíveis, {vehicleStats.maintenance_count} em manutenção
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Usuários</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{userStats.total_count}</div>
            <p className="text-xs text-muted-foreground">
              {userStats.admin_count} administradores, {userStats.requester_count} solicitantes
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Reservas Recentes</CardTitle>
          <CardDescription>
            {location === "Todos" ? "Todas as reservas recentes" : `Reservas recentes em ${location}`}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {recentReservations.length === 0 ? (
            <p className="text-center py-4 text-muted-foreground">Nenhuma reserva recente encontrada.</p>
          ) : (
            <div className="space-y-4">
              {recentReservations.map((reservation) => (
                <div key={reservation.id} className="flex items-center justify-between border-b pb-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{reservation.vehicle_model}</span>
                      {getStatusBadge(reservation.status)}
                    </div>
                    <div className="text-sm text-muted-foreground">Solicitante: {reservation.user_name}</div>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Calendar className="mr-1 h-3 w-3" />
                      <span>
                        {formatDate(reservation.pickup_date)} a {formatDate(reservation.return_date)}
                      </span>
                    </div>
                  </div>
                  <div className="text-sm text-muted-foreground">{formatDate(reservation.created_at)}</div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
