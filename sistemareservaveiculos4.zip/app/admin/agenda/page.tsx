import { requireAdmin } from "@/lib/auth"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { executeQuery } from "@/lib/db"
import { AgendaViewTabular } from "./agenda-view-tabular"

export default async function AgendaPage() {
  const user = await requireAdmin()

  // Busca todas as reservas aprovadas
  const approvedReservations = await executeQuery(`
    SELECT r.*, v.model as vehicle_model, v.plate as vehicle_plate, u.name as user_name, u.email as user_email
    FROM reservations r
    JOIN vehicles v ON r.vehicle_id = v.id
    JOIN users u ON r.user_id = u.id
    WHERE r.status IN ('pendente', 'aprovada', 'em_andamento', 'concluida')
    ORDER BY r.pickup_date ASC, r.pickup_time ASC
  `)

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Agenda de Reservas</h1>
          <p className="text-muted-foreground">Visualize todas as reservas em formato de agenda</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Agenda</CardTitle>
            <CardDescription>Reservas pendentes e concluídas</CardDescription>
          </CardHeader>
          <CardContent>
            <AgendaViewTabular initialReservations={approvedReservations} />
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
