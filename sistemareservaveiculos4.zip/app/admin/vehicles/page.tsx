import { requireAdmin } from "@/lib/auth"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { executeQuery } from "@/lib/db"
import { VehicleManagement } from "./vehicle-management"

export default async function VehiclesPage() {
  const user = await requireAdmin()

  // Busca todos os veículos
  const vehicles = await executeQuery(`
    SELECT * FROM vehicles
    ORDER BY model ASC
  `)

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Gestão de Veículos</h1>
          <p className="text-muted-foreground">Adicione, edite e gerencie os veículos disponíveis para reserva</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Veículos</CardTitle>
            <CardDescription>Lista de todos os veículos cadastrados no sistema</CardDescription>
          </CardHeader>
          <CardContent>
            <VehicleManagement initialVehicles={vehicles} />
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
