import { requireAdmin } from "@/lib/auth"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { executeQuery } from "@/lib/db"
import { ReservationManagement } from "./reservation-management"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default async function ReservationsPage() {
  const user = await requireAdmin()

  // Busca todas as reservas
  const pendingReservations = await executeQuery(`
    SELECT r.*, v.model as vehicle_model, v.plate as vehicle_plate, u.name as user_name, u.email as user_email
    FROM reservations r
    JOIN vehicles v ON r.vehicle_id = v.id
    JOIN users u ON r.user_id = u.id
    WHERE r.status = 'pendente'
    ORDER BY r.created_at DESC
  `)

  const completedReservations = await executeQuery(`
    SELECT r.*, v.model as vehicle_model, v.plate as vehicle_plate, u.name as user_name, u.email as user_email
    FROM reservations r
    JOIN vehicles v ON r.vehicle_id = v.id
    JOIN users u ON r.user_id = u.id
    WHERE r.status IN ('concluida', 'cancelada')
    ORDER BY r.created_at DESC
    LIMIT 50
  `)

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Gestão de Reservas</h1>
          <p className="text-muted-foreground">Gerencie todas as reservas de veículos</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Reservas</CardTitle>
            <CardDescription>Visualize, aprove, rejeite e gerencie as reservas</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="pending">
              <TabsList className="mb-4">
                <TabsTrigger value="pending">Pendentes ({pendingReservations.length})</TabsTrigger>
                <TabsTrigger value="completed">Concluídas/Rejeitadas</TabsTrigger>
              </TabsList>

              <TabsContent value="pending">
                <ReservationManagement reservations={pendingReservations} />
              </TabsContent>

              <TabsContent value="completed">
                <ReservationManagement reservations={completedReservations} />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
