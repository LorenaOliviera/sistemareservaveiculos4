"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, Search, Eye, CheckCircle, XCircle, Trash2 } from "lucide-react"
import { formatDate, formatTime } from "@/lib/utils"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { useRouter, useSearchParams } from "next/navigation"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Reservation {
  id: number
  reservation_code: string
  requester_name: string
  pickup_date: string
  return_date: string
  pickup_time: string
  return_time: string
  location: string
  status: string
  vehicle_model: string
  vehicle_plate: string
  reason: string
  user_name: string
  user_email: string
  cost_center: string
  vehicle_id: number
}

interface ReservationManagementProps {
  reservations: Reservation[]
}

export function ReservationManagement({ reservations: initialReservations }: ReservationManagementProps) {
  const router = useRouter()
  const searchParams = useSearchParams()

  const [reservations, setReservations] = useState<Reservation[]>(initialReservations)
  const [searchTerm, setSearchTerm] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const [selectedReservation, setSelectedReservation] = useState<Reservation | null>(null)
  const [filterLocation, setFilterLocation] = useState<string>("")
  const [confirmDeleteDialogOpen, setConfirmDeleteDialogOpen] = useState(false)
  const [reservationToDelete, setReservationToDelete] = useState<number | null>(null)

  // Filtra reservas com base no termo de busca e localização
  const filteredReservations = reservations.filter((reservation) => {
    const matchesSearch =
      reservation.reservation_code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      reservation.requester_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      reservation.vehicle_model.toLowerCase().includes(searchTerm.toLowerCase()) ||
      reservation.vehicle_plate.toLowerCase().includes(searchTerm.toLowerCase()) ||
      reservation.user_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      reservation.user_email.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesLocation = !filterLocation || filterLocation === "all" || reservation.location === filterLocation

    return matchesSearch && matchesLocation
  })

  const handleCompleteReservation = async (id: number) => {
    setLoading(true)

    try {
      const response = await fetch(`/api/reservations/${id}/complete`, {
        method: "POST",
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Erro ao concluir reserva")
      }

      // Atualiza a lista de reservas
      setReservations(
        reservations.map((reservation) =>
          reservation.id === id ? { ...reservation, status: "concluida" } : reservation,
        ),
      )

      // Fecha o diálogo
      setSelectedReservation(null)

      // Atualiza a página
      router.refresh()
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleRejectReservation = async (id: number) => {
    setLoading(true)

    try {
      const response = await fetch(`/api/reservations/${id}/reject`, {
        method: "POST",
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Erro ao rejeitar reserva")
      }

      // Atualiza a lista de reservas
      setReservations(
        reservations.map((reservation) =>
          reservation.id === id ? { ...reservation, status: "cancelada" } : reservation,
        ),
      )

      // Fecha o diálogo
      setSelectedReservation(null)

      // Atualiza a página
      router.refresh()
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteReservation = async (id: number) => {
    setLoading(true)

    try {
      const response = await fetch(`/api/reservations/${id}`, {
        method: "DELETE",
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Erro ao excluir reserva")
      }

      // Remove a reserva da lista
      setReservations(reservations.filter((reservation) => reservation.id !== id))

      // Fecha o diálogo de confirmação
      setConfirmDeleteDialogOpen(false)
      setReservationToDelete(null)

      // Fecha o diálogo de detalhes se estiver aberto
      setSelectedReservation(null)

      // Atualiza a página
      router.refresh()
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const openDeleteConfirmDialog = (id: number) => {
    setReservationToDelete(id)
    setConfirmDeleteDialogOpen(true)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pendente":
        return (
          <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">
            Pendente
          </Badge>
        )
      case "concluida":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
            Concluída
          </Badge>
        )
      case "cancelada":
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">
            Rejeitada
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="space-y-4">
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="relative w-full sm:w-64">
            <Input
              placeholder="Buscar reserva..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8"
            />
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          </div>

          <Select value={filterLocation} onValueChange={setFilterLocation}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filtrar por local" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os locais</SelectItem>
              <SelectItem value="MG1">MG1</SelectItem>
              <SelectItem value="MG2">MG2</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Código</TableHead>
              <TableHead>Solicitante</TableHead>
              <TableHead>Veículo</TableHead>
              <TableHead>Local</TableHead>
              <TableHead>Período</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredReservations.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-4 text-muted-foreground">
                  Nenhuma reserva encontrada.
                </TableCell>
              </TableRow>
            ) : (
              filteredReservations.map((reservation) => (
                <TableRow key={reservation.id}>
                  <TableCell className="font-medium">{reservation.reservation_code}</TableCell>
                  <TableCell>{reservation.requester_name}</TableCell>
                  <TableCell>
                    {reservation.vehicle_model} ({reservation.vehicle_plate})
                  </TableCell>
                  <TableCell>{reservation.location}</TableCell>
                  <TableCell>
                    {formatDate(reservation.pickup_date)} a {formatDate(reservation.return_date)}
                  </TableCell>
                  <TableCell>{getStatusBadge(reservation.status)}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => setSelectedReservation(reservation)}>
                      <Eye className="h-4 w-4" />
                    </Button>
                    {(reservation.status === "concluida" || reservation.status === "cancelada") && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openDeleteConfirmDialog(reservation.id)}
                        className="text-red-500 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {selectedReservation && (
        <Dialog open={!!selectedReservation} onOpenChange={(open) => !open && setSelectedReservation(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Detalhes da Reserva</DialogTitle>
              <DialogDescription>Código: {selectedReservation.reservation_code}</DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium">Veículo</h4>
                  <p>
                    {selectedReservation.vehicle_model} - {selectedReservation.vehicle_plate}
                  </p>
                </div>
                <div>
                  <h4 className="font-medium">Status</h4>
                  <div>{getStatusBadge(selectedReservation.status)}</div>
                </div>
                <div>
                  <h4 className="font-medium">Reservista</h4>
                  <p>{selectedReservation.requester_name}</p>
                </div>
                <div>
                  <h4 className="font-medium">Centro de Custo</h4>
                  <p>{selectedReservation.cost_center}</p>
                </div>
                <div>
                  <h4 className="font-medium">Usuário</h4>
                  <p>{selectedReservation.user_name}</p>
                  <p className="text-xs text-muted-foreground">{selectedReservation.user_email}</p>
                </div>
                <div>
                  <h4 className="font-medium">Local</h4>
                  <p>{selectedReservation.location}</p>
                </div>
                <div>
                  <h4 className="font-medium">Período</h4>
                  <p>
                    {formatDate(selectedReservation.pickup_date)} a {formatDate(selectedReservation.return_date)}
                  </p>
                </div>
                <div>
                  <h4 className="font-medium">Horário</h4>
                  <p>
                    {formatTime(selectedReservation.pickup_time)} às {formatTime(selectedReservation.return_time)}
                  </p>
                </div>
              </div>

              <div>
                <h4 className="font-medium">Motivo</h4>
                <p className="text-sm">{selectedReservation.reason}</p>
              </div>
            </div>

            <DialogFooter>
              {selectedReservation.status === "pendente" && (
                <>
                  <Button
                    variant="outline"
                    onClick={() => handleRejectReservation(selectedReservation.id)}
                    disabled={loading}
                    className="border-red-200 text-red-700 hover:bg-red-50"
                  >
                    <XCircle className="mr-2 h-4 w-4" />
                    {loading ? "Processando..." : "Rejeitar"}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => handleCompleteReservation(selectedReservation.id)}
                    disabled={loading}
                    className="border-green-200 text-green-700 hover:bg-green-50"
                  >
                    <CheckCircle className="mr-2 h-4 w-4" />
                    {loading ? "Processando..." : "Concluir"}
                  </Button>
                </>
              )}

              {(selectedReservation.status === "concluida" || selectedReservation.status === "cancelada") && (
                <Button
                  variant="destructive"
                  onClick={() => openDeleteConfirmDialog(selectedReservation.id)}
                  disabled={loading}
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  {loading ? "Processando..." : "Excluir Reserva"}
                </Button>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Diálogo de confirmação de exclusão */}
      <Dialog open={confirmDeleteDialogOpen} onOpenChange={setConfirmDeleteDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Confirmar Exclusão</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir esta reserva? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() => {
                setConfirmDeleteDialogOpen(false)
                setReservationToDelete(null)
              }}
            >
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={() => reservationToDelete && handleDeleteReservation(reservationToDelete)}
              disabled={loading}
            >
              {loading ? "Excluindo..." : "Excluir"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
