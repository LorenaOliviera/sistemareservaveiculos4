import { getCurrentUser } from "@/lib/auth"
import { redirect } from "next/navigation"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default async function Home() {
  const user = await getCurrentUser()

  // Redireciona para o dashboard se o usuário estiver logado
  if (user) {
    if (user.role === "admin") {
      redirect("/admin/dashboard")
    } else {
      redirect("/dashboard")
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-secondary/30">
      <div className="w-full max-w-4xl px-4 py-8 text-center">
        <h1 className="text-5xl font-bold mb-2">
          <span className="text-gray-800">Reservas de Veículos</span>
          <span className="text-primary"> LD Celulose</span>
        </h1>

        <p className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto">
          Gerencie reservas de veículos corporativos com facilidade. Sistema completo para controle de frota e
          aprovações.
        </p>

        <div className="flex flex-col md:flex-row gap-6 justify-center mt-12">
          <Link href="/login?role=solicitante">
            <Button className="w-64 h-20 text-xl bg-primary hover:bg-primary/90">Área do Solicitante</Button>
          </Link>

          <Link href="/login?role=admin">
            <Button
              variant="outline"
              className="w-64 h-20 text-xl border-2 border-primary text-primary hover:bg-primary/10"
            >
              Área do Administrador
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
