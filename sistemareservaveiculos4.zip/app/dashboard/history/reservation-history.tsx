"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { formatDate, formatTime } from "@/lib/utils"
import { Calendar, Clock, MapPin, Car, Pencil } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"
import { EditReservation } from "./edit-reservation"

interface Reservation {
  id: number
  reservation_code: string
  requester_name: string
  pickup_date: string
  return_date: string
  pickup_time: string
  return_time: string
  location: string
  status: string
  vehicle_model: string
  vehicle_plate: string
  reason: string
  vehicle_id: number
}

export function ReservationHistory() {
  const [reservations, setReservations] = useState<Reservation[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [cancelLoading, setCancelLoading] = useState(false)
  const [editingReservation, setEditingReservation] = useState<Reservation | null>(null)
  const [selectedReservation, setSelectedReservation] = useState<Reservation | null>(null)

  useEffect(() => {
    fetchReservations()
  }, [])

  const fetchReservations = async () => {
    try {
      const response = await fetch("/api/reservations")

      if (!response.ok) {
        throw new Error("Erro ao buscar reservas")
      }

      const data = await response.json()
      setReservations(data)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleCancelReservation = async (id: number) => {
    setCancelLoading(true)

    try {
      const response = await fetch(`/api/reservations/${id}/cancel`, {
        method: "POST",
      })

      if (!response.ok) {
        throw new Error("Erro ao cancelar reserva")
      }

      // Atualiza a lista de reservas
      fetchReservations()

      // Fecha o diálogo de detalhes se estiver aberto
      setSelectedReservation(null)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setCancelLoading(false)
    }
  }

  const handleReservationUpdated = (updatedReservation: Reservation) => {
    console.log("Reserva atualizada:", updatedReservation)

    // Atualiza a reserva na lista
    setReservations(
      reservations.map((reservation) => (reservation.id === updatedReservation.id ? updatedReservation : reservation)),
    )

    // Atualiza a reserva selecionada se estiver aberta
    if (selectedReservation && selectedReservation.id === updatedReservation.id) {
      setSelectedReservation(updatedReservation)
    }

    // Fecha o diálogo de edição
    setEditingReservation(null)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pendente":
        return (
          <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">
            Pendente
          </Badge>
        )
      case "aprovada":
        return (
          <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">
            Aprovada
          </Badge>
        )
      case "em_andamento":
        return (
          <Badge variant="outline" className="bg-primary/20 text-primary border-primary">
            Em Andamento
          </Badge>
        )
      case "concluida":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
            Concluída
          </Badge>
        )
      case "cancelada":
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">
            Cancelada
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  if (loading) {
    return <div className="text-center py-8">Carregando reservas...</div>
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    )
  }

  if (reservations.length === 0) {
    return <div className="text-center py-8 text-muted-foreground">Você ainda não possui reservas.</div>
  }

  return (
    <div className="space-y-4">
      {reservations.map((reservation) => (
        <Card key={reservation.id} className="overflow-hidden">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row justify-between gap-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-lg">{reservation.vehicle_model}</h3>
                  {getStatusBadge(reservation.status)}
                </div>

                <p className="text-sm text-muted-foreground">Código: {reservation.reservation_code}</p>

                <div className="flex items-center text-sm">
                  <Car className="mr-2 h-4 w-4" />
                  <span>{reservation.vehicle_plate}</span>
                </div>

                <div className="flex items-center text-sm">
                  <MapPin className="mr-2 h-4 w-4" />
                  <span>Local: {reservation.location}</span>
                </div>

                <div className="flex items-center text-sm">
                  <Calendar className="mr-2 h-4 w-4" />
                  <span>
                    {formatDate(reservation.pickup_date)} a {formatDate(reservation.return_date)}
                  </span>
                </div>

                <div className="flex items-center text-sm">
                  <Clock className="mr-2 h-4 w-4" />
                  <span>
                    {formatTime(reservation.pickup_time)} às {formatTime(reservation.return_time)}
                  </span>
                </div>
              </div>

              <div className="flex flex-col gap-2 md:items-end justify-between">
                <Button variant="outline" onClick={() => setSelectedReservation(reservation)}>
                  Ver Detalhes
                </Button>

                {reservation.status === "pendente" && (
                  <>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setEditingReservation(reservation)
                      }}
                      className="border-blue-200 text-blue-700 hover:bg-blue-50"
                    >
                      <Pencil className="mr-2 h-4 w-4" />
                      Editar
                    </Button>

                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleCancelReservation(reservation.id)}
                      disabled={cancelLoading}
                    >
                      {cancelLoading ? "Cancelando..." : "Cancelar"}
                    </Button>
                  </>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}

      {selectedReservation && (
        <Dialog open={!!selectedReservation} onOpenChange={(open) => !open && setSelectedReservation(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Detalhes da Reserva</DialogTitle>
              <DialogDescription>Código: {selectedReservation.reservation_code}</DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium">Veículo</h4>
                  <p>
                    {selectedReservation.vehicle_model} - {selectedReservation.vehicle_plate}
                  </p>
                </div>
                <div>
                  <h4 className="font-medium">Status</h4>
                  <div>{getStatusBadge(selectedReservation.status)}</div>
                </div>
                <div>
                  <h4 className="font-medium">Reservista</h4>
                  <p>{selectedReservation.requester_name}</p>
                </div>
                <div>
                  <h4 className="font-medium">Local</h4>
                  <p>{selectedReservation.location}</p>
                </div>
                <div>
                  <h4 className="font-medium">Período</h4>
                  <p>
                    {formatDate(selectedReservation.pickup_date)} a {formatDate(selectedReservation.return_date)}
                  </p>
                </div>
                <div>
                  <h4 className="font-medium">Horário</h4>
                  <p>
                    {formatTime(selectedReservation.pickup_time)} às {formatTime(selectedReservation.return_time)}
                  </p>
                </div>
              </div>

              <div>
                <h4 className="font-medium">Motivo</h4>
                <p className="text-sm">{selectedReservation.reason}</p>
              </div>
            </div>

            <DialogFooter>
              {selectedReservation.status === "pendente" && (
                <>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setEditingReservation(selectedReservation)
                      setSelectedReservation(null)
                    }}
                    disabled={cancelLoading}
                    className="border-blue-200 text-blue-700 hover:bg-blue-50"
                  >
                    <Pencil className="mr-2 h-4 w-4" />
                    Editar Reserva
                  </Button>
                  <Button
                    variant="destructive"
                    onClick={() => handleCancelReservation(selectedReservation.id)}
                    disabled={cancelLoading}
                  >
                    {cancelLoading ? "Cancelando..." : "Cancelar Reserva"}
                  </Button>
                </>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {editingReservation && (
        <Dialog open={!!editingReservation} onOpenChange={(open) => !open && setEditingReservation(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Editar Reserva</DialogTitle>
              <DialogDescription>Código: {editingReservation.reservation_code}</DialogDescription>
            </DialogHeader>

            <EditReservation
              reservation={editingReservation}
              onClose={() => setEditingReservation(null)}
              onSuccess={handleReservationUpdated}
            />
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
